declare module 'ogl';
