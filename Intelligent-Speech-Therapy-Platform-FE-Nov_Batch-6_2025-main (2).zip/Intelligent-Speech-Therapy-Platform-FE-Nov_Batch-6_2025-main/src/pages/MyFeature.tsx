import React, { useState, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./AssessmentPage.css";

interface AssessmentSentence {
  id: number;
  text: string;
  difficulty: "easy" | "medium" | "hard";
}

/* Mic Icon Component */
const MicIcon: React.FC = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
    <rect x="9" y="4" width="6" height="10" rx="3" fill="currentColor" opacity="0.9" />
    <path
      d="M6 10a6 6 0 0012 0"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
    <path
      d="M12 16v3.5M9.5 19.5h5"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
  </svg>
);

const AssessmentPage: React.FC = () => {
  const navigate = useNavigate();

  // Only ONE sentence (as requested)
  const assessmentSentences: AssessmentSentence[] = [
    {
      id: 1,
      text: "The quick brown fox jumps over the lazy dog.",
      difficulty: "easy",
    },
  ];

  const [currentSentenceIndex] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudio, setRecordedAudio] = useState<Blob | null>(null);
  const [audioURL, setAudioURL] = useState("");
  const [uploadMessage, setUploadMessage] = useState("");
  const [isUploading, setIsUploading] = useState(false);

  // Timer state (no time limit)
  const [recordTime, setRecordTime] = useState(0);
  const timerRef = useRef<number | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);

  const currentSentence = assessmentSentences[currentSentenceIndex];

  // Start recording and start timer
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];
      setRecordTime(0);
      setUploadMessage("");

      // start timer
      timerRef.current = window.setInterval(() => {
        setRecordTime((prev) => prev + 1);
      }, 1000);

      recorder.ondataavailable = (evt: BlobEvent) => {
        if (evt.data && evt.data.size > 0) audioChunksRef.current.push(evt.data);
      };

      recorder.onstop = () => {
        // stop timer
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }

        const blob = new Blob(audioChunksRef.current, { type: "audio/wav" });
        setRecordedAudio(blob);
        setAudioURL(URL.createObjectURL(blob));
        // stop tracks
        stream.getTracks().forEach((t) => t.stop());
      };

      recorder.start();
      setIsRecording(true);
    } catch (err) {
      alert("Error accessing microphone. Please allow microphone permission.");
      console.error(err);
    }
  };

  // Stop recording and stop timer
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  // Re-record: clear previously recorded audio and start new recording
  const reRecord = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setRecordedAudio(null);
    setAudioURL("");
    setRecordTime(0);
    startRecording();
  };

  // Upload recorded audio (frontend-only; adapt endpoint as needed)
  const uploadAudio = async () => {
    if (!recordedAudio) {
      alert("Please record audio first.");
      return;
    }

    setIsUploading(true);
    setUploadMessage("");

    try {
      const formData = new FormData();
      formData.append("sentenceId", currentSentence.id.toString());
      formData.append("sentenceText", currentSentence.text);
      formData.append("audio", recordedAudio, "assessment_audio.wav");

      // Example endpoint - adapt to your backend
      const response = await fetch("http://localhost:8000/api/assessments/upload", {
        method: "POST",
        body: formData,
        headers: {
          // If you use auth token
          Authorization: `Bearer ${localStorage.getItem("token") || ""}`,
        },
      });

      if (response.ok) {
        const data = await response.json().catch(() => ({}));
        setUploadMessage(`✓ Uploaded successfully! Score: ${(data && data.score) || "N/A"}`);
      } else {
        setUploadMessage("Upload failed. Please try again.");
      }
    } catch (err) {
      console.error(err);
      setUploadMessage("Upload error. Check network or backend.");
    } finally {
      setIsUploading(false);
    }
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
        try {
          mediaRecorderRef.current.stop();
        } catch {}
      }
    };
  }, []);

  // format timer mm:ss
  const formatTime = (seconds: number) => {
    const mm = Math.floor(seconds / 60)
      .toString()
      .padStart(2, "0");
    const ss = (seconds % 60).toString().padStart(2, "0");
    return `${mm}:${ss}`;
  };

  return (
    <div className="assessment-container">
      <header className="assessment-header">
        <div className="assessment-header-inner">
          <h1 className="assessment-title">Speech Assessment</h1>
          <button className="back-button" onClick={() => navigate("/dashboard")}>
            ← Back to Dashboard
          </button>
        </div>
      </header>

      <main className="assessment-content">
        <div className="assessment-wrapper">
          {/* Progress bar */}
          <div className="assessment-progress">
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: "100%" }} />
            </div>
            <p className="progress-text">Sentence {currentSentenceIndex + 1} of {assessmentSentences.length}</p>
          </div>

          {/* Sentence card */}
          <div className="sentence-card">
            <div className="difficulty-badge">
              <span className={`badge-${currentSentence.difficulty}`}>
                {currentSentence.difficulty.toUpperCase()}
              </span>
            </div>

            <div className="sentence-display">
              <h2 className="sentence-text">{currentSentence.text}</h2>
              <p className="sentence-instruction">Read the sentence aloud clearly and naturally</p>
            </div>
          </div>

          {/* Recording card */}
          <div className="recording-card">
            <h3 className="recording-title">Record Your Speech</h3>

            {/* Recording controls: compact start button + waveform + timer */}
            {!recordedAudio ? (
              <div className="recording-controls">
                {!isRecording ? (
                  <button className="record-button" onClick={startRecording} aria-label="Start Recording">
                    <span className="record-icon"><MicIcon /></span>
                    Start Recording
                  </button>
                ) : (
                  <button className="record-button recording" onClick={stopRecording} aria-label="Stop Recording">
                    <span className="dot-indicator" /> Stop Recording
                  </button>
                )}

                {/* waveform-like animation while recording */}
                {isRecording && (
                  <div className="recording-visualizer" aria-hidden>
                    <span className="bar b1" />
                    <span className="bar b2" />
                    <span className="bar b3" />
                    <span className="bar b4" />
                    <span className="bar b5" />
                  </div>
                )}

                {/* timer */}
                {isRecording && (
                  <div className="timer-box">
                    <span className="record-timer">{formatTime(recordTime)}</span>
                  </div>
                )}

                {/* hint */}
                <p className="recording-hint">
                  {isRecording ? "Recording... click Stop when finished." : "Click Start to begin recording."}
                </p>
              </div>
            ) : (
              /* Playback + actions */
              <div className="playback-controls">
                <div className="audio-player">
                  <audio ref={audioElementRef} src={audioURL} controls className="audio-element" />
                </div>

                <div className="action-buttons">
                  <button className="action-btn rerecord-btn" onClick={reRecord} disabled={isUploading}>
                    🔄 Re-record
                  </button>

                  <button className="action-btn upload-btn" onClick={uploadAudio} disabled={isUploading}>
                    {isUploading ? "Uploading..." : "✓ Upload"}
                  </button>
                </div>

                {uploadMessage && (
                  <p className={`upload-message ${uploadMessage.startsWith("✓") ? "success" : "error"}`}>
                    {uploadMessage}
                  </p>
                )}
              </div>
            )}
          </div>

        </div>
      </main>
    </div>
  );
};

export default AssessmentPage;