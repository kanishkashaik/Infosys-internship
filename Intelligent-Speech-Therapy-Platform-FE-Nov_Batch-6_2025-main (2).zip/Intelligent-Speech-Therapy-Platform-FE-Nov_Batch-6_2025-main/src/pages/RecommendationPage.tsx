import React, { useEffect, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import apiClient from "../api/apiClient";
import roboGif from "../assets/robo3.gif";
import "./AssessmentPage.css";

type PhonemeResult = { symbol: string; accuracy: number };
type WordResult = { text: string; correct: boolean };



interface PracticeRecommendation {
  sentence_id?: number;
  text: string;
  phonemes?: string[];
  difficulty: string;
  matched?: string[];
}



const RecommendationPage: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const payloadFromNav = (location.state as any) || null;
  const [payload, setPayload] = useState<any | null>(null);

  useEffect(() => {
    if (payloadFromNav) {
      setPayload(payloadFromNav);
      try {
        sessionStorage.setItem("last_assessment", JSON.stringify(payloadFromNav));
      } catch {}
      return;
    }
    try {
      const raw = sessionStorage.getItem("last_assessment");
      if (raw) setPayload(JSON.parse(raw));
    } catch {}
  }, [payloadFromNav]);

  const detailed = payload?.detailedResults ?? payload ?? null;
  const lastMetrics = payload?.lastMetrics ?? null;
  const sentence = payload?.sentence ?? "";
  
  // Debug logging to understand the data structure
  console.log('=== RecommendationPage Debug ===');
  console.log('Full payload:', payload);
  console.log('detailed:', detailed);
  console.log('detailed?.weakPhonemes:', detailed?.weakPhonemes);
  console.log('detailed?.computed_weak_phonemes:', detailed?.computed_weak_phonemes);
  
  const weakPhonemes: string[] = detailed?.weakPhonemes || detailed?.computed_weak_phonemes || [];

  const phonemes: PhonemeResult[] = Array.isArray(detailed?.phonemes) ? detailed.phonemes : [];
  const words: WordResult[] = Array.isArray(detailed?.words) ? detailed.words : [];

  console.log('phonemes array:', phonemes);
  console.log('words array:', words);

  const phonemesToPractice = phonemes
    .filter((p) => typeof p.accuracy === "number" && p.accuracy < 80)
    .sort((a, b) => a.accuracy - b.accuracy);

  const wordsToPractice = words.filter((w) => !w.correct).slice(0, 20);

  // Extract only the text from incorrect words for the API call
  const weakWords: string[] = wordsToPractice.map((w) => w.text);
  
  console.log('weakPhonemes:', weakPhonemes);
  console.log('weakWords:', weakWords);
  console.log('phonemesToPractice:', phonemesToPractice);
  console.log('wordsToPractice:', wordsToPractice);
  console.log('=== End Debug ===');

  // Practice recommendations from backend
  const [practiceRecommendations, setPracticeRecommendations] = useState<PracticeRecommendation[]>([]);
  const [currentPracticeIndex, setCurrentPracticeIndex] = useState<number | null>(null);
  const [isLoadingRecommendations, setIsLoadingRecommendations] = useState(false);
  const [recommendationError, setRecommendationError] = useState<string | null>(null);
  
  // Practice sentences and recording state
  const [recordedBlob, setRecordedBlob] = useState<Blob | null>(null);
  const [currentPractice, setCurrentPractice] = useState<PracticeRecommendation | null>(null);
  const [practiceResults, setPracticeResults] = useState<any | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionError, setSubmissionError] = useState<string | null>(null);
  const [evaluationResults, setEvaluationResults] = useState<any | null>(null);

    // Track if we've already fetched recommendations to prevent infinite loops
  const fetchedPhonemesRef = useRef<string>("");

  // Fetch practice recommendations from backend API
  useEffect(() => {
    // Only fetch if we have weak phonemes or words to practice
    if (weakPhonemes.length === 0 && weakWords.length === 0) {
      setPracticeRecommendations([]);
      setIsLoadingRecommendations(false);
      return;
    }

    // Create a unique key to prevent duplicate fetches
    const fetchKey = `${weakPhonemes.join(',')}_${weakWords.join(',')}`;
    
    // Skip if we've already fetched for these phonemes/words
    if (fetchedPhonemesRef.current === fetchKey) {
      return;
    }

    const fetchRecommendations = async () => {
      setIsLoadingRecommendations(true);
      setRecommendationError(null);
      fetchedPhonemesRef.current = fetchKey;

      try {
        // Build query parameters
        const params = new URLSearchParams();
        if (weakPhonemes.length > 0) {
          params.append('weak_phonemes', weakPhonemes.join(','));
        }
        if (weakWords.length > 0) {
          params.append('weak_words', weakWords.join(','));
        }

        console.log('Fetching practice recommendations with params:', params.toString());

        const response = await apiClient.get(`/practice/recommendation?${params.toString()}`);
        console.log(response)
        // Log the raw response for debugging
        console.log('Raw API response:', response);
        console.log('response.data:', response.data);
        console.log('Is response.data an array?', Array.isArray(response.data));
        
        // Handle new API format: { sentences: [{text, difficulty}, ...] }
        let recommendations: any[] = [];
        
        if (response.data?.sentences && Array.isArray(response.data.sentences)) {
          // New format: { sentences: [...] }
          recommendations = response.data.sentences;
        } else if (response.data?.recommendations && Array.isArray(response.data.recommendations)) {
          // Old format: { recommendations: [...] }
          recommendations = response.data.recommendations;
        } else if (response.data?.data && Array.isArray(response.data.data)) {
          // Alternative format: { data: [...] }
          recommendations = response.data.data;
        } else if (Array.isArray(response.data)) {
          // Direct array format
          recommendations = response.data;
        } else if (response.data?.text) {
          // Single object {text, difficulty}
          recommendations = [response.data];
        }

        console.log('Parsed recommendations:', recommendations);
        console.log('Recommendations count:', recommendations.length);

        // Map the recommendations to ensure they have all required fields
        const mappedRecommendations: PracticeRecommendation[] = recommendations.map((rec: any, index: number) => ({
          sentence_id: rec.sentence_id ?? index + 1, // Use index as fallback if sentence_id is null
          text: rec.text || '',
          phonemes: Array.isArray(rec.phonemes) ? rec.phonemes : [],
          difficulty: rec.difficulty || 'medium',
          matched: Array.isArray(rec.matched) ? rec.matched : []
        }));

        console.log('Mapped recommendations:', mappedRecommendations);
        console.log('Setting practiceRecommendations state with', mappedRecommendations.length, 'items');

        setPracticeRecommendations(mappedRecommendations);
        
        // Auto-select the first recommendation if available
        if (mappedRecommendations.length > 0) {
          setCurrentPracticeIndex(0);
          setCurrentPractice(mappedRecommendations[0]);
        }
      } catch (error: any) {
        console.error('Error fetching practice recommendations:', error);
        setRecommendationError(
          error?.response?.data?.message || 
          'Failed to load practice recommendations. Please try again.'
        );
        fetchedPhonemesRef.current = ''; // Reset to allow retry
      } finally {
        setIsLoadingRecommendations(false);
      }
    };

    fetchRecommendations();
  }, [weakPhonemes, weakWords]);
  
  const currentPracticeSentenceId = currentPractice?.sentence_id ?? null;

  // Recording state
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedUrl, setRecordedUrl] = useState<string | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];
      recorder.ondataavailable = (e: BlobEvent) => {
        if (e.data && e.data.size > 0) audioChunksRef.current.push(e.data);
      };
      recorder.onstop = () => {
        const blob = new Blob(audioChunksRef.current, { type: "audio/wav" });
        const url = URL.createObjectURL(blob);
        setRecordedUrl(url);
        setRecordedBlob(blob);
        stream.getTracks().forEach((t) => t.stop());
      };
      recorder.start();
      setIsRecording(true);
    } catch (e) {
      console.error(e);
      alert("Microphone access required to record practice attempts.");
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };



  // Submit practice audio for evaluation
  const submitPracticeAudio = async () => {
    if (!recordedBlob || !currentPractice) {
      alert("Please record audio first and select a sentence.");
      return;
    }

    setIsSubmitting(true);
    setSubmissionError(null);
    setEvaluationResults(null);

    try {
      const formData = new FormData();
      formData.append("audio", recordedBlob, "practice_audio.wav");
      formData.append("sentence_id", String(currentPractice.sentence_id));

      const response = await apiClient.post("/practice/submit", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      });

      const data = response?.data?.data || response?.data;
      
      // Log the response for debugging
      console.log("Practice evaluation response:", response.data);
      console.log("Extracted data:", data);
      
      // Helper function to safely extract numeric value
      const safeNumber = (value: any): number => {
        if (typeof value === 'number' && !isNaN(value)) return value;
        if (typeof value === 'string') {
          const parsed = parseFloat(value);
          return isNaN(parsed) ? 0 : parsed;
        }
        return 0;
      };
      
      // Parse detailed results
      const details = data.details || {};
      
      // Parse phoneme_details from the backend structure
      const rawPhonemes: any[] | undefined = details?.phoneme_details;
      const phonemes: PhonemeResult[] | undefined = Array.isArray(rawPhonemes)
        ? (rawPhonemes
            .map((p) => ({
              symbol: String(p.symbol ?? p.phoneme ?? p.phone ?? "?"),
              accuracy:
                typeof p.accuracy === "number"
                  ? p.accuracy
                  : typeof p.score === "number"
                  ? p.score
                  : undefined,
            }))
            .filter((p) => typeof p.accuracy === "number") as PhonemeResult[])
        : undefined;

      // Parse word_details from the backend structure
      const rawWords: any[] | undefined = details?.word_details;
      const words: WordResult[] | undefined = Array.isArray(rawWords)
        ? rawWords.map((w) => ({
            text: String(w.text ?? w.word ?? ""),
            correct:
              w.correct === undefined 
                ? (w.status ? w.status.toLowerCase() !== "mispronounced" : w.is_correct !== false)
                : !!w.correct,
          }))
        : undefined;

      // Extract metrics from backend response
      // Backend now returns:
      // - phoneme_accuracy (avg) → Display as "Sentence Accuracy"
      // - word_accuracy (avg) → Display as "Overall Accuracy"  
      // - fluency_score → Display as "Word Accuracy"
      const sentenceAccuracy = safeNumber(data.phoneme_accuracy);  // Sentence Accuracy
      const overallAccuracy = safeNumber(data.word_accuracy);      // Overall Accuracy (main score)
      const wordAccuracy = safeNumber(data.fluency_score);         // Word Accuracy
      
      console.log("Extracted metrics:", { sentenceAccuracy, overallAccuracy, wordAccuracy });
      
      // Use overall accuracy as the main score
      const overallScore = overallAccuracy;

      // Get weak phonemes from backend response
      const weakPhonemes = data.weak_phonemes || data.computed_weak_phonemes || [];
      const mistakesSummary = weakPhonemes.length > 0 
        ? `Weak phonemes detected: ${weakPhonemes.join(", ")}`
        : "Great job! No significant weak phonemes detected.";
      
      setEvaluationResults({
        sentenceAccuracy,      // Sentence Accuracy
        overallAccuracy,       // Overall Accuracy (main score)
        wordAccuracy,          // Word Accuracy
        overallScore,          // Same as overallAccuracy
        computed_weak_phonemes: weakPhonemes,
        phonemes,
        words,
        mistakesSummary,
      });
    } catch (error: any) {
      console.error("Error submitting practice audio:", error);
      setSubmissionError(
        error?.response?.data?.message || "Failed to submit practice audio. Please try again."
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!detailed) {
    return (
      <div className="assessment-container">
        <header className="assessment-header">
          <div className="assessment-header-inner">
            <div className="assessment-title-block">
              <h1 className="assessment-title">Recommendations</h1>
            </div>
            <button className="back-button recommendations-btn" onClick={() => { window.location.href = "/dashboard"; }}>
              ← Back to Dashboard
            </button>
          </div>
        </header>

        <main className="assessment-content">
          <div className="assessment-wrapper" style={{ padding: 24 }}>
            <p>No assessment data available. Complete an assessment to see personalized recommendations.</p>
            <div style={{ marginTop: 18 }}>
              <button className="action-btn recommendations-btn" onClick={() => { window.location.href = "/assessment"; }}>
                Go to Assessment
              </button>
            </div>
          </div>
        </main>

        <div
          role="dialog"
          aria-modal="true"
          style={{
            position: "fixed",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "rgba(0,0,0,0.45)",
            zIndex: 1200,
          }}
        >
          <div
            style={{
              background: "#fff",
              padding: 24,
              borderRadius: 16,
              maxWidth: 520,
              width: "90%",
              boxShadow: "0 8px 24px rgba(0,0,0,0.2)",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              textAlign: "center",
            }}
          >
            <div style={{ marginBottom: 16 }}>
              <img 
                src={roboGif} 
                alt="Robot illustration" 
                style={{ 
                  width: 120, 
                  height: "auto",
                  animation: "robot-bob 2s ease-in-out infinite"
                }} 
              />
            </div>
            <h2 
              style={{ 
                marginTop: 0,
                marginBottom: 12,
                fontFamily: '"Krona One", serif',
                fontSize: "1.8rem",
                color: "#4f46e5",
                textTransform: "uppercase",
                letterSpacing: "0.04em"
              }}
            >
              Assessment required
            </h2>
            <p style={{ 
              color: "#6b7280", 
              fontSize: "0.95rem",
              marginBottom: 20,
              lineHeight: 1.6
            }}>
              You need to complete at least one assessment before viewing recommendations.
            </p>
            <div style={{ display: "flex", gap: 8, justifyContent: "center", marginTop: 8 }}>
              <button 
                className="action-btn recommendations-btn" 
                onClick={() => {
                  window.location.href = "/assessment";
                }}
              >
                Back to Assessment
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="assessment-container">
      <header className="assessment-header">
        <div className="assessment-header-inner">
          <div className="assessment-title-block">
            <h1 className="assessment-title">Recommendations</h1>
            <p className="assessment-subtitle">Exercises tailored from your recent assessment</p>
          </div>
          <button className="back-button recommendations-btn" onClick={() => { window.location.href = "/dashboard"; }}>← Back to Dashboard</button>
        </div>
      </header>

      <main className="assessment-content">
        <div className="assessment-wrapper">
          <div style={{ padding: 18 }}>
            <div style={{ marginBottom: 12, fontSize: 20, fontWeight: 600 }}>
              <strong>Sentence assessed:</strong>
              <div style={{ marginTop: 6 }}>{sentence}</div>
            </div>

            {lastMetrics && (
              <div style={{ display: "flex", gap: 16, marginBottom: 12, flexWrap: "wrap" }}>
                {/* <div className="metric">Fluency: <span className="metric-value">{Math.round(lastMetrics.fluency_score ?? 0)}</span></div> */}
                <div className="metric">Phoneme acc.: <span className="metric-value">{Math.round(lastMetrics.phoneme_accuracy ?? 0)}</span></div>
                <div className="metric">Word acc.: <span className="metric-value">{Math.round(lastMetrics.word_accuracy ?? 0)}</span></div>
              </div>
            )}

            <div style={{ marginTop: 8 }}>
              <h3>Weak Phonemes Detected</h3>
              {weakPhonemes.length === 0 ? (
                <p>No weak phonemes detected — great job!</p>
              ) : (
                <div className="phoneme-grid">
                  {weakPhonemes.map((p, idx) => (
                    <div key={`${p}-${idx}`} className="phoneme-chip bad">
                      <div style={{ fontSize: 18, fontWeight: 700 }}>{p}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* <div style={{ marginTop: 12 }}>
              <h3>Phonemes to practice</h3>
              {phonemesToPractice.length === 0 ? (
                <p>None detected — keep practicing the full sentence.</p>
              ) : (
                <div className="phoneme-grid">
                  {phonemesToPractice.map((p, idx) => (
                    <div key={`${p.symbol}-${idx}`} className="phoneme-chip bad">
                      <div style={{ fontSize: 18, fontWeight: 700 }}>{p.symbol}</div>
                      <div style={{ fontSize: 13 }}>Accuracy: {Math.round(p.accuracy)}%</div>
                    </div>
                  ))}
                </div>
              )}
            </div> */}

            <div style={{ marginTop: 12 }}>
              <h3>Words to practice</h3>
              {wordsToPractice.length === 0 ? (
                <p>No mispronounced words detected.</p>
              ) : (
                <div className="results-words-line">
                  {wordsToPractice.map((w, i) => (
                    <span key={`${w.text}-${i}`} style={{ display: "inline-block", marginRight: 8, padding: "6px 10px", border: "1px solid #e5e7eb", borderRadius: 999 }}>
                      {w.text}
                    </span>
                  ))}
                </div>
              )}
            </div>

            <div style={{ marginTop: 32 }}>
              <h2 style={{ fontSize: '2rem', fontWeight: 700, marginBottom: 8, color: '#1f2937' }}>Practice Recommendations</h2>
              <p className="subtle" style={{ fontSize: '1rem', color: '#6b7280', marginBottom: 24 }}>Practice sentences recommended based on your weak phonemes and words.</p>

              {isLoadingRecommendations ? (
                <div style={{ padding: 20, textAlign: "center" }}>
                  <p>Loading practice recommendations...</p>
                </div>
              ) : recommendationError ? (
                <div style={{ padding: 20, color: "#dc2626" }}>
                  <p>{recommendationError}</p>
                </div>
              ) : practiceRecommendations.length === 0 ? (
                <div style={{ padding: 20 }}>
                  <p className="subtle">No practice recommendations available. Complete an assessment with weak phonemes to get recommendations.</p>
                </div>
              ) : (
                <div style={{ marginTop: 12 }}>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 20 }}>
                    {practiceRecommendations.map((rec, idx) => (
                      <div
                        key={idx}
                        onClick={() => {
                          setCurrentPracticeIndex(idx);
                          setCurrentPractice(rec);
                          setPracticeResults(null);
                          setRecordedUrl(null);
                          setRecordedBlob(null);
                          setEvaluationResults(null);
                          try {
                            sessionStorage.setItem("selected_practice", JSON.stringify(rec));
                          } catch {}
                        }}
                        style={{ 
                          cursor: "pointer", 
                          padding: 20, 
                          borderRadius: 16, 
                          border: idx === currentPracticeIndex ? "3px solid #4f46e5" : "2px solid #e5e7eb",
                          backgroundColor: idx === currentPracticeIndex ? "#eef2ff" : "#fff",
                          boxShadow: idx === currentPracticeIndex ? "0 8px 24px rgba(79, 70, 229, 0.15)" : "0 2px 8px rgba(0, 0, 0, 0.05)",
                          transition: "all 0.3s ease",
                          position: "relative",
                          overflow: "hidden"
                        }}
                      >
                        {/* Difficulty Badge */}
                        <div style={{ 
                          position: "absolute",
                          top: 12,
                          right: 12,
                          fontSize: 11, 
                          padding: "4px 12px", 
                          borderRadius: 16, 
                          fontWeight: 600,
                          textTransform: "uppercase",
                          letterSpacing: "0.5px",
                          backgroundColor: rec.difficulty === "easy" ? "#dcfce7" : rec.difficulty === "medium" ? "#fef3c7" : "#fee2e2",
                          color: rec.difficulty === "easy" ? "#166534" : rec.difficulty === "medium" ? "#92400e" : "#991b1b"
                        }}>
                          {rec.difficulty}
                        </div>
                        
                        {/* Sentence Text */}
                        <div style={{ 
                          fontSize: 16, 
                          fontWeight: 600, 
                          lineHeight: 1.6,
                          color: "#1f2937",
                          paddingRight: 80,
                          marginBottom: 8
                        }}>
                          {rec.text}
                        </div>
                        
                        {/* Selection Indicator */}
                        {idx === currentPracticeIndex && (
                          <div style={{ 
                            marginTop: 12,
                            padding: "8px 12px",
                            backgroundColor: "#4f46e5",
                            color: "white",
                            borderRadius: 8,
                            fontSize: 12,
                            fontWeight: 600,
                            textAlign: "center"
                          }}>
                            ✓ Selected for Practice
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Practice Recording Section */}
              {currentPractice && (
                <div style={{ marginTop: 32, padding: 24, backgroundColor: "#f9fafb", borderRadius: 16, border: "2px solid #e5e7eb" }}>
                  <h3 style={{ fontSize: '1.5rem', fontWeight: 700, marginBottom: 16, color: '#1f2937' }}>Practice Session</h3>
                  
                  {/* Selected Sentence Display with Record Button */}
                  <div style={{ 
                    display: "flex", 
                    alignItems: "center", 
                    justifyContent: "space-between",
                    gap: 16,
                    padding: 20, 
                    backgroundColor: "#fff", 
                    borderRadius: 12, 
                    marginBottom: 20,
                    boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)",
                    flexWrap: "wrap"
                  }}>
                    <div style={{ flex: 1, minWidth: 250 }}>
                      <div style={{ fontSize: 12, color: "#6b7280", marginBottom: 6, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>Selected Sentence</div>
                      <div style={{ fontSize: 18, fontWeight: 600, color: "#1f2937", lineHeight: 1.6, marginBottom: 8 }}>{currentPractice.text}</div>
                      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                        <span style={{ 
                          fontSize: 11, 
                          padding: "3px 10px", 
                          borderRadius: 12, 
                          fontWeight: 600,
                          textTransform: "uppercase",
                          backgroundColor: currentPractice.difficulty === "easy" ? "#dcfce7" : currentPractice.difficulty === "medium" ? "#fef3c7" : "#fee2e2",
                          color: currentPractice.difficulty === "easy" ? "#166534" : currentPractice.difficulty === "medium" ? "#92400e" : "#991b1b"
                        }}>
                          {currentPractice.difficulty}
                        </span>
                      </div>
                    </div>
                    
                    {/* Recording Controls on the Right */}
                    <div style={{ display: "flex", flexDirection: "column", gap: 10, alignItems: "flex-end" }}>
                      {!isRecording ? (
                        <button 
                          className="record-button pulse recommendations-btn" 
                          onClick={() => startRecording()}
                          style={{
                            padding: "12px 24px",
                            fontSize: 16,
                            fontWeight: 600,
                            borderRadius: 12,
                            backgroundColor: "#ef4444",
                            color: "white",
                            border: "none",
                            cursor: "pointer",
                            boxShadow: "0 4px 12px rgba(239, 68, 68, 0.3)",
                            transition: "all 0.3s ease",
                            display: "flex",
                            alignItems: "center",
                            gap: 8
                          }}
                        >
                          <span style={{ fontSize: 20 }}>🎤</span>
                          Start Practice
                        </button>
                      ) : (
                        <button 
                          className="record-button recording recommendations-btn" 
                          onClick={() => stopRecording()}
                          style={{
                            padding: "12px 24px",
                            fontSize: 16,
                            fontWeight: 600,
                            borderRadius: 12,
                            backgroundColor: "#dc2626",
                            color: "white",
                            border: "none",
                            cursor: "pointer",
                            animation: "pulse 1.5s ease-in-out infinite",
                            display: "flex",
                            alignItems: "center",
                            gap: 8
                          }}
                        >
                          <span style={{ fontSize: 20 }}>⏹️</span>
                          Stop Recording
                        </button>
                      )}
                    </div>
                  </div>
                  
                  {/* Audio Playback and Submit */}
                  {recordedUrl && (
                    <div style={{ 
                      padding: 16, 
                      backgroundColor: "#fff", 
                      borderRadius: 12, 
                      marginBottom: 20,
                      boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)"
                    }}>
                      <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 12, color: "#374151" }}>Your Recording</div>
                      <div style={{ display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                        <audio src={recordedUrl} controls style={{ flex: 1, minWidth: 250 }} />
                        <button
                          className="action-btn recommendations-btn"
                          onClick={submitPracticeAudio}
                          disabled={isSubmitting}
                          style={{
                            padding: "10px 20px",
                            fontSize: 15,
                            fontWeight: 600,
                            borderRadius: 10,
                            backgroundColor: isSubmitting ? "#9ca3af" : "#4f46e5",
                            color: "white",
                            border: "none",
                            cursor: isSubmitting ? "not-allowed" : "pointer",
                            boxShadow: "0 4px 12px rgba(79, 70, 229, 0.3)",
                            transition: "all 0.3s ease"
                          }}
                        >
                          {isSubmitting ? (
                            <>
                              <span className="spinner" style={{ marginRight: 6 }} aria-hidden />
                              Evaluating...
                            </>
                          ) : (
                            "Submit for Evaluation"
                          )}
                        </button>
                      </div>
                    </div>
                  )}
                  
                  {submissionError && (
                    <div style={{ 
                      marginTop: 12, 
                      padding: 16, 
                      backgroundColor: "#fee2e2", 
                      borderRadius: 12, 
                      color: "#dc2626",
                      border: "2px solid #fca5a5",
                      fontWeight: 500
                    }}>
                      ⚠️ {submissionError}
                    </div>
                  )}
                  {/* Evaluation Results - Displayed Below Practice Session */}
                  {evaluationResults && (
                    <div style={{ marginTop: 24, padding: 24, backgroundColor: "#f0f9ff", borderRadius: 16, border: "3px solid #3b82f6", boxShadow: "0 8px 24px rgba(59, 130, 246, 0.15)" }}>
                      <h3 style={{ marginTop: 0, marginBottom: 16, color: "#1e40af", display: "flex", alignItems: "center", gap: 10, fontSize: '1.75rem', fontWeight: 700 }}>
                        <span style={{ fontSize: 32 }}>📊</span>
                        Evaluation Results
                      </h3>
                    
                      {/* Overall Score */}
                      {evaluationResults.overallScore !== undefined && (
                        <div style={{ marginBottom: 20, padding: 24, backgroundColor: "white", borderRadius: 16, textAlign: "center", boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)" }}>
                          <div style={{ fontSize: 16, color: "#6b7280", marginBottom: 8, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>Overall Score</div>
                          <div style={{ fontSize: 64, fontWeight: 800, color: "#3b82f6", marginBottom: 8 }}>
                            {Math.round(evaluationResults.overallScore)}
                          </div>
                          <div style={{ fontSize: 16, color: "#6b7280", fontWeight: 600 }}>
                            {evaluationResults.overallScore >= 80 ? "🎉 Excellent!" : evaluationResults.overallScore >= 60 ? "👍 Good job!" : "💪 Keep practicing!"}
                          </div>
                        </div>
                      )}

                      {/* Mistakes Summary */}
                      {evaluationResults.mistakesSummary && (
                        <div style={{ marginBottom: 20, padding: 16, backgroundColor: "#fef3c7", borderRadius: 12, border: "2px solid #fbbf24" }}>
                          <div style={{ fontSize: 15, fontWeight: 700, color: "#92400e", marginBottom: 6 }}>Summary</div>
                          <div style={{ fontSize: 14, color: "#78350f", lineHeight: 1.6 }}>{evaluationResults.mistakesSummary}</div>
                        </div>
                      )}


                      {/* Metric Cards - Display all three accuracy metrics */}
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 20 }}>
                      {/* <div style={{ padding: 12, backgroundColor: "white", borderRadius: 8, textAlign: "center", border: "1px solid #e0e7ff" }}>
                        <div style={{ fontSize: 12, color: "#6b7280", marginBottom: 4 }}>Overall Accuracy</div>
                        <div style={{ fontSize: 24, fontWeight: 700, color: "#6366f1" }}>
                          {typeof evaluationResults.overallAccuracy === 'number' && !isNaN(evaluationResults.overallAccuracy) 
                            ? Math.round(evaluationResults.overallAccuracy) 
                            : 'N/A'}
                        </div>
                      </div> */}
                        <div style={{ padding: 16, backgroundColor: "white", borderRadius: 12, textAlign: "center", border: "2px solid #e0e7ff", boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                          <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 6, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>Word Accuracy</div>
                          <div style={{ fontSize: 32, fontWeight: 700, color: "#6366f1" }}>
                            {typeof evaluationResults.wordAccuracy === 'number' && !isNaN(evaluationResults.wordAccuracy) 
                              ? Math.round(evaluationResults.wordAccuracy) 
                              : 'N/A'}
                          </div>
                        </div>
                        <div style={{ padding: 16, backgroundColor: "white", borderRadius: 12, textAlign: "center", border: "2px solid #e0e7ff", boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                          <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 6, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>Sentence Accuracy</div>
                          <div style={{ fontSize: 32, fontWeight: 700, color: "#6366f1" }}>
                            {typeof evaluationResults.sentenceAccuracy === 'number' && !isNaN(evaluationResults.sentenceAccuracy) 
                              ? Math.round(evaluationResults.sentenceAccuracy) 
                              : 'N/A'}
                          </div>
                        </div>
                      </div>

                    {/* Detailed Phoneme Results
                    {evaluationResults.phonemes && evaluationResults.phonemes.length > 0 && (
                      <div style={{ marginTop: 16, padding: 16, backgroundColor: "white", borderRadius: 10 }}>
                        <h5 style={{ marginTop: 0, marginBottom: 12, fontSize: 15, fontWeight: 600 }}>Phoneme Breakdown</h5>
                        <div style={{ display: "grid", gap: 10 }}>
                          {evaluationResults.phonemes.map((p, idx) => (
                            <div key={idx} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                              <div style={{ 
                                minWidth: 50, 
                                fontWeight: 600, 
                                fontSize: 14,
                                color: p.accuracy >= 80 ? "#059669" : p.accuracy >= 60 ? "#d97706" : "#dc2626"
                              }}>
                                {p.symbol}
                              </div>
                              <div style={{ flex: 1, backgroundColor: "#f3f4f6", borderRadius: 999, height: 8, overflow: "hidden" }}>
                                <div style={{ 
                                  width: `${Math.min(100, Math.max(0, p.accuracy))}%`,
                                  height: "100%",
                                  backgroundColor: p.accuracy >= 80 ? "#10b981" : p.accuracy >= 60 ? "#f59e0b" : "#ef4444",
                                  transition: "width 0.3s ease"
                                }} />
                              </div>
                              <div style={{ 
                                minWidth: 45, 
                                textAlign: "right", 
                                fontSize: 13, 
                                fontWeight: 600,
                                color: p.accuracy >= 80 ? "#059669" : p.accuracy >= 60 ? "#d97706" : "#dc2626"
                              }}>
                                {Math.round(p.accuracy)}%
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )} */}

                      {/* Word-by-Word Results */}
                      {evaluationResults.words && evaluationResults.words.length > 0 && (
                        <div style={{ marginTop: 20, padding: 20, backgroundColor: "white", borderRadius: 12, boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                          <h4 style={{ marginTop: 0, marginBottom: 16, fontSize: 18, fontWeight: 700, color: "#374151" }}>Word-by-Word Analysis</h4>
                          <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                            {evaluationResults.words.map((w, idx) => (
                              <span
                                key={idx}
                                style={{
                                  padding: "8px 16px",
                                  borderRadius: 8,
                                  fontSize: 14,
                                  fontWeight: 600,
                                  backgroundColor: w.correct ? "#d1fae5" : "#fee2e2",
                                  color: w.correct ? "#065f46" : "#991b1b",
                                  border: `2px solid ${w.correct ? "#6ee7b7" : "#fca5a5"}`,
                                }}
                              >
                                {w.correct ? "✓" : "✗"} {w.text}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}

                      {/* Weak Phonemes */}
                      {evaluationResults.computed_weak_phonemes && evaluationResults.computed_weak_phonemes.length > 0 && (
                        <div style={{ marginTop: 20, padding: 20, backgroundColor: "white", borderRadius: 12, boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                          <h4 style={{ marginTop: 0, marginBottom: 12, fontSize: 18, fontWeight: 700, color: "#374151" }}>Weak Phonemes Detected</h4>
                          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                            {evaluationResults.computed_weak_phonemes.map((phoneme, idx) => (
                              <span
                                key={idx}
                                style={{
                                  padding: "8px 16px",
                                  backgroundColor: "#fef3c7",
                                  color: "#92400e",
                                  borderRadius: 20,
                                  fontSize: 14,
                                  fontWeight: 700,
                                  border: "2px solid #fbbf24"
                                }}
                              >
                                {phoneme}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              )}
              </div>
              {/* End Practice Recording Section */}
              
              {practiceResults && (
                <div style={{ marginTop: 16, padding: 12, background: "#f9fafb", borderRadius: 8, border: "1px solid #e5e7eb" }}>
                  <h4>Practice Results</h4>
                  <div style={{ display: "flex", gap: 16, marginTop: 8, flexWrap: "wrap" }}>
                    {practiceResults.fluency_score !== undefined && (
                      <div className="metric">Fluency: <span className="metric-value">{Math.round(practiceResults.fluency_score)}</span></div>
                    )}
                    {practiceResults.phoneme_accuracy !== undefined && (
                      <div className="metric">Phoneme acc.: <span className="metric-value">{Math.round(practiceResults.phoneme_accuracy)}</span></div>
                    )}
                    {practiceResults.word_accuracy !== undefined && (
                      <div className="metric">Word acc.: <span className="metric-value">{Math.round(practiceResults.word_accuracy)}</span></div>
                    )}
                  </div>
                  {Array.isArray(practiceResults.computed_weak_phonemes) && practiceResults.computed_weak_phonemes.length > 0 && (
                    <div style={{ marginTop: 8 }}>
                      <strong>Weak Phonemes:</strong> {practiceResults.computed_weak_phonemes.join(", ")}
                    </div>
                  )}
                </div>
              )}

              <div style={{ marginTop: 20 }}>
                <button className="action-btn recommendations-btn" onClick={() => { window.location.href = "/assessment"; }}>Back to Assessment</button>
              </div>
            </div>

          </div>
      </main>
    </div>
  );
};

export default RecommendationPage;
