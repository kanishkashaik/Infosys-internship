declare module './AssessmentPage.css';
