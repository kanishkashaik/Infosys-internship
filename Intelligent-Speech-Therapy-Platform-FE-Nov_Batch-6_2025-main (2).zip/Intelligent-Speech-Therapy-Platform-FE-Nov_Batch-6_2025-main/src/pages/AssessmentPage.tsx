import React, { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import apiClient from "../api/apiClient";
import { saveAssessmentToHistory } from "../api/historyApi";
import roboGif from "../assets/illu2.png";
import InfoModal from "../components/InfoModal";
import { ASSESSMENT_BASE_URL } from "../config/env";
import { useAuth } from "../context/AuthContext";
import "./AssessmentPage.css";

interface AssessmentSentence {
  id: number;
  text: string;
  difficulty: "easy" | "medium" | "hard";
}

type PhonemeResult = {
  symbol: string;
  accuracy: number;
};

type WordResult = {
  text: string;
  correct: boolean;
};

// Fallback sentence if backend fetch fails
const assessmentSentences: AssessmentSentence[] = [
  {
    id: 1,
    text: "The quick brown fox jumps over the lazy dog.",
    difficulty: "easy",
  },
];

const SCORE_PHRASES: string[] = [
  "Zero the hero - every journey starts here!",
  "One and done? No way, you've just begun!",
  "Two steps in - let's begin!",
];

/* Mic Icon Component */
const MicIcon: React.FC = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden="true">
    <rect
      x="9"
      y="4"
      width="6"
      height="10"
      rx="3"
      fill="currentColor"
      opacity="0.9"
    />
    <path
      d="M6 10a6 6 0 0012 0"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
    <path
      d="M12 16v3.5M9.5 19.5h5"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
    />
  </svg>
);

/* Speedometer Gauge Component for Word Accuracy */
const SpeedometerGauge: React.FC<{ score: number }> = ({ score }) => {
  const clampedScore = Math.min(100, Math.max(0, score));
  const rotation = (clampedScore / 100) * 180 - 90; // -90 to 90 degrees
  
  // Determine color based on score
  const getColor = (score: number) => {
    if (score >= 80) return "#10b981"; // green
    if (score >= 60) return "#f59e0b"; // yellow/orange
    return "#ef4444"; // red
  };
  
  const color = getColor(clampedScore);
  
  return (
    <div style={{ 
      position: "relative", 
      width: 200, 
      height: 120, 
      margin: "0 auto",
      marginBottom: 16
    }}>
      {/* Semi-circle gauge background */}
      <svg width="200" height="120" viewBox="0 0 200 120" style={{ overflow: "visible" }}>
        {/* Background arc */}
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke="#e5e7eb"
          strokeWidth="20"
          strokeLinecap="round"
        />
        {/* Colored arc based on score */}
        <path
          d="M 20 100 A 80 80 0 0 1 180 100"
          fill="none"
          stroke={color}
          strokeWidth="20"
          strokeLinecap="round"
          strokeDasharray={`${(clampedScore / 100) * 251.2} 251.2`}
          style={{ transition: "stroke-dasharray 1s ease-out" }}
        />
        {/* Needle */}
        <line
          x1="100"
          y1="100"
          x2="100"
          y2="30"
          stroke="#374151"
          strokeWidth="3"
          strokeLinecap="round"
          style={{
            transformOrigin: "100px 100px",
            transform: `rotate(${rotation}deg)`,
            transition: "transform 1s ease-out"
          }}
        />
        {/* Center dot */}
        <circle cx="100" cy="100" r="6" fill="#374151" />
      </svg>
      
      {/* Score display */}
      <div style={{
        position: "absolute",
        bottom: 0,
        left: "50%",
        transform: "translateX(-50%)",
        fontSize: 32,
        fontWeight: 800,
        color: color,
        textAlign: "center"
      }}>
        {Math.round(clampedScore)}
        <div style={{ fontSize: 12, color: "#6b7280", fontWeight: 600, marginTop: -4 }}>WORD ACCURACY</div>
      </div>
    </div>
  );
};

const USE_DEMO_RESULTS = false; // disable demo bypass — use real backend


const AssessmentPage: React.FC = () => {
  const navigate = useNavigate();

  // Single sentence fetched from backend (frontend unaware which will arrive)
  const [fetchedSentence, setFetchedSentence] =
    useState<AssessmentSentence | null>(null);
  const [currentSentenceIndex] = useState(0);
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudio, setRecordedAudio] = useState<Blob | null>(null);
  const [audioURL, setAudioURL] = useState("");
  const [uploadMessage, setUploadMessage] = useState("");
  const [isUploading, setIsUploading] = useState(false);
  const [lastMetrics, setLastMetrics] = useState<{
    fluency_score?: number;
    phoneme_accuracy?: number;
    word_accuracy?: number;
  } | null>(null);
  const [animatedMetrics, setAnimatedMetrics] = useState<{
    fluency_score?: number;
    phoneme_accuracy?: number;
    word_accuracy?: number;
  }>({});

  const [detailedResults, setDetailedResults] = useState<{
    overallScore?: number;
    mistakesSummary?: string;
    phonemes?: PhonemeResult[];
    words?: WordResult[];
    referenceAudioUrl?: string;
    weakPhonemes?: string[];
  } | null>(null);

  // Timer state (no time limit)
  const [recordTime, setRecordTime] = useState(0);
  const timerRef = useRef<number | null>(null);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const metricsAnimationFrameRef = useRef<number | null>(null);
  const [isPlaybackPlaying, setIsPlaybackPlaying] = useState(false);
  const [recommendLoading, setRecommendLoading] = useState(false);
  const [recommendedPhonemes, setRecommendedPhonemes] = useState<
    string[] | null
  >(null);
  const [recommendReason, setRecommendReason] = useState<string | null>(null);
  const [recommendedFetched, setRecommendedFetched] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [alertModal, setAlertModal] = useState<{ visible: boolean; title?: string; message: string }>({
    visible: false,
    message: ""
  });

  const currentSentence = assessmentSentences[currentSentenceIndex];
  // expose a safe getter for the sentence text (fallback to legacy hardcoded text)
  const sentenceText =
    fetchedSentence?.text ??
    (assessmentSentences && assessmentSentences[currentSentenceIndex]?.text) ??
    "Please read the sentence provided.";

  // fetch one sentence from backend: GET /assessment/recommend
  useEffect(() => {
    let cancelled = false;

    // Auto TTS disabled: do not speak the sentence automatically on load.

    const tryPaths = ["/assessement/next"];

    const attempt = async () => {
      try {
        const res = await apiClient.get("/assessment/recommend");
        const body = res?.data ?? {};
        const text = body.text;
        // Note: Contract doesn't show sentence_id in response, but upload requires it.
        // Using fallback to 1 if not present. Backend may return it despite not being in contract example.
        const id = body.sentence_id || body.id || 1;
        if (text) {
          const sent: AssessmentSentence = { id, text, difficulty: body.difficulty || "easy" };
          if (!cancelled) {
            setFetchedSentence(sent);
          }
          return;
        }
      } catch (e) {
        // ignore
      }

      for (const p of tryPaths) {
        try {
          const res = await apiClient.get(p);
          const body = res?.data ?? {};
          const text =
            body.sentence ||
            body.text ||
            (body.data && (body.data.sentence || body.data.text));
          const id = body.sentence_id || body.id || (body.data && (body.data.sentence_id || body.data.id)) || 1;
          if (text) {
            const sent: AssessmentSentence = { id, text, difficulty: "easy" };
            if (!cancelled) {
              setFetchedSentence(sent);
            }
            return;
          }
        } catch (e) {
          // ignore and try next path
        }
      }

      if (!cancelled) {
        const fallback = assessmentSentences[0];
        setFetchedSentence(fallback);
      }
    };

    attempt();

    return () => {
      cancelled = true;
    };
  }, []);

  // Fetch a recommended sentence on-demand from backend
  const fetchRecommendedSentence = async () => {
    setRecommendLoading(true);
    try {
      console.debug("Attempting recommendation fetch via apiClient");
      const res = await apiClient.get(`/assessment/recommend?user_id=${localStorage.getItem("user_id") || "4"}`);
      const data = res?.data ?? res;

      const text = data?.text;
      const phonemes = data?.phonemes;
      const difficulty = data?.difficulty ?? "easy";
      const id = data?.sentence_id ?? data?.id ?? 0;
      localStorage.setItem("sentence_id", id);

      if (text) {
        setFetchedSentence({ id, text, difficulty });
        setRecommendedPhonemes(
          Array.isArray(phonemes) ? phonemes.map(String) : null
        );
        setRecommendReason(data?.reason ?? null);
        setRecommendedFetched(true);
      } else {
        console.error("Recommendation response missing text", data);
        setAlertModal({
          visible: true,
          title: "Recommendation Error",
          message: "Recommendation response did not include a sentence. Please check the backend or try again."
        });
      }
    } catch (err: any) {
      console.error("Error fetching recommendation:", err);
      // Axios-like error handling
      if (err?.response) {
        console.error(
          "Server response:",
          err.response.status,
          err.response.data
        );
        setAlertModal({
          visible: true,
          title: "Recommendation Failed",
          message: `Failed to fetch recommendation: ${err.response.status} ${err.response.statusText || ""}. Please try again.`
        });
      } else if (err?.request) {
        console.error(
          "No response received (possible CORS or network issue):",
          err.request
        );
        setAlertModal({
          visible: true,
          title: "Network Error",
          message: "Network or CORS error when fetching recommendation. Please check your connection and try again."
        });
      } else {
        setAlertModal({
          visible: true,
          title: "Unexpected Error",
          message: "An unexpected error occurred while fetching the recommendation. Please try again later."
        });
      }
    } finally {
      setRecommendLoading(false);
    }
  };

  // Start recording and start timer
  const startRecording = async () => {
    if (!recommendedFetched) {
      setAlertModal({
        visible: true,
        title: "Recommendation Required",
        message: "Please click 'Recommend Sentence' to fetch a sentence before recording."
      });
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      audioChunksRef.current = [];
      setRecordTime(0);
      setUploadMessage("");

      // start timer
      timerRef.current = window.setInterval(() => {
        setRecordTime((prev) => prev + 1);
      }, 1000);

      recorder.ondataavailable = (evt: BlobEvent) => {
        if (evt.data && evt.data.size > 0)
          audioChunksRef.current.push(evt.data);
      };

      recorder.onstop = () => {
        // stop timer
        if (timerRef.current) {
          clearInterval(timerRef.current);
          timerRef.current = null;
        }

        const blob = new Blob(audioChunksRef.current, { type: "audio/wav" });
        setRecordedAudio(blob);
        setAudioURL(URL.createObjectURL(blob));
        // stop tracks
        stream.getTracks().forEach((t) => t.stop());
      };

      recorder.start();
      setIsRecording(true);
    } catch (err) {
      alert("Error accessing microphone. Please allow microphone permission.");
      console.error(err);
    }
  };

  // Temporary handler to bypass analysis and show demo results immediately.
  // DEV bypass removed: analysis now requires backend.

  // Stop recording and stop timer
  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }
  };

  // Re-record: clear previously recorded audio and start new recording
  const reRecord = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setRecordedAudio(null);
    setAudioURL("");
    setRecordTime(0);
    startRecording();
  };

  const { user, token } = useAuth();

  // Upload audio to backend
  const uploadAudio = async () => {
    if (!recordedAudio) {
      alert("Please record audio first.");
      return;
    }

    setIsUploading(true);
    setUploadMessage("");
    setLastMetrics(null);

    // Demo mode: bypass backend and fabricate results so UI works even if API is down.
    if (USE_DEMO_RESULTS) {
      setTimeout(() => {
        const demoMetrics = {
          fluency_score: 82,
          phoneme_accuracy: 76,
          word_accuracy: 88,
        };
        setLastMetrics(demoMetrics);

        setDetailedResults({
          overallScore: 81,
          mistakesSummary:
            "You tended to shorten vowel sounds in 'quick' and 'lazy', and your final consonant in 'dog' was slightly dropped.",
          phonemes: [
            { symbol: "/ð/", accuracy: 78 },
            { symbol: "/ɪ/", accuracy: 70 },
            { symbol: "/k/", accuracy: 90 },
            { symbol: "/b/", accuracy: 88 },
            { symbol: "/r/", accuracy: 60 },
            { symbol: "/ɔː/", accuracy: 72 },
          ],
          words: [
            { text: "The", correct: true },
            { text: "quick", correct: false },
            { text: "brown", correct: true },
            { text: "fox", correct: true },
            { text: "jumps", correct: true },
            { text: "over", correct: true },
            { text: "the", correct: true },
            { text: "lazy", correct: false },
            { text: "dog.", correct: false },
          ],
          referenceAudioUrl: undefined,
        });

        // hide any previous upload text once scores are shown
        setUploadMessage("");
        setIsUploading(false);
      }, 900);
      return;
    }

    const userId = user?.id ?? localStorage.getItem("user_id") ?? "1";
    const sentenceId = (fetchedSentence?.id ?? currentSentence.id).toString();

    try {
      const formData = new FormData();
      // Use actual IDs we computed earlier
      formData.append("user_id", String(localStorage.getItem("user_id") ?? userId));
      formData.append("sentence_id", String(localStorage.getItem("sentence_id") ?? sentenceId));
      // Backend expects key `audio_file` according to API docs
      formData.append("audio", recordedAudio, "assessment_audio.wav");

      // Backend provided path (note spelling): /assessement/upload
      const uploadUrl = `${ASSESSMENT_BASE_URL.replace(
        /\/$/,
        ""
      )}/assessment/upload`;
      console.debug("Uploading assessment to:", uploadUrl, {
        userId,
        sentenceId,
      });

      // Do not send Authorization header here to keep CORS simpler (backend should accept form-data)
      let response: Response;
      try {
        response = await fetch(uploadUrl, {
          method: "POST",
          body: formData,
          mode: "cors",
        });
      } catch (networkErr: any) {
        console.error("Network error during upload:", networkErr);
        setUploadMessage(
          `Upload failed: network error (${String(
            networkErr?.message || networkErr
          )}). Check console for details.`
        );
        setIsUploading(false);
        return;
      }

      if (response.ok) {
        const data = await response.json();
        const statusCode = data?.StatusCode ?? data?.statusCode;
        const metrics = data?.data || {};
        const root: any = data || {};
        const metricRoot: any = metrics || {};
        const details = metrics?.details || {};

        setLastMetrics({
          fluency_score: metrics.fluency_score,
          phoneme_accuracy: metrics.phoneme_accuracy,
          word_accuracy: metrics.word_accuracy,
        });

        // Store weak_Phoneme for practice recommendations
        if (Array.isArray(metrics.weak_Phoneme)) {
          try {
            sessionStorage.setItem("weak_Phoneme", JSON.stringify(metrics.weak_Phoneme));
          } catch {}
        }

        // Save to assessment history
        try {
          saveAssessmentToHistory({
            id: Date.now(),
            sentence_id: Number(sentenceId),
            sentence_text: sentenceText,
            date: new Date().toISOString(),
            fluency_score: metrics.fluency_score || 0,
            phoneme_accuracy: metrics.phoneme_accuracy || 0,
            word_accuracy: metrics.word_accuracy || 0,
            weak_Phoneme: Array.isArray(metrics.weak_Phoneme) ? metrics.weak_Phoneme : undefined,
          });
        } catch {}

        // Build richer results module if backend provides more detail.
        
        // Extract weak phonemes from the response
        const weakPhonemes: string[] | undefined = 
          Array.isArray(metrics.weak_Phoneme) ? metrics.weak_Phoneme :
          Array.isArray(metrics.weak_phonemes) ? metrics.weak_phonemes :
          Array.isArray(details?.weak_phonemes) ? details.weak_phonemes :
          undefined;

        const rawPhonemes: any[] | undefined =
          details?.phoneme_details ||
          metricRoot.phonemes ||
          metricRoot.phoneme_results ||
          root.phonemes ||
          root.phoneme_results;

        const phonemes: PhonemeResult[] | undefined = Array.isArray(rawPhonemes)
          ? (rawPhonemes
              .map((p) => ({
                symbol: String(p.symbol ?? p.phoneme ?? p.phone ?? "?"),
                accuracy:
                  typeof p.accuracy === "number"
                    ? p.accuracy
                    : typeof p.score === "number"
                    ? p.score
                    : undefined,
              }))
              .filter((p) => typeof p.accuracy === "number") as PhonemeResult[])
          : undefined;

        // Parse word_details from the new backend structure
        const rawWords: any[] | undefined =
          details?.word_details ||
          metricRoot.words ||
          metricRoot.word_results ||
          root.words ||
          root.word_results;

        const words: WordResult[] | undefined = Array.isArray(rawWords)
          ? rawWords.map((w) => ({
              text: String(w.text ?? w.word ?? ""),
              correct:
                w.correct === undefined 
                  ? (w.status ? w.status.toLowerCase() !== "mispronounced" : w.is_correct !== false)
                  : !!w.correct,
            }))
          : undefined;

        // Calculate overall score from the three metrics if not provided
        const overallScore: number | undefined =
          typeof metricRoot.overall_score === "number"
            ? metricRoot.overall_score
            : typeof metricRoot.sentence_score === "number"
            ? metricRoot.sentence_score
            : typeof root.overall_score === "number"
            ? root.overall_score
            : (metrics.fluency_score !== undefined && 
               metrics.phoneme_accuracy !== undefined && 
               metrics.word_accuracy !== undefined)
            ? Math.round((metrics.fluency_score + metrics.phoneme_accuracy + metrics.word_accuracy) / 3)
            : undefined;

        const mistakesSummary: string | undefined =
          metricRoot.mistakes_summary ??
          root.mistakes_summary ??
          (weakPhonemes && weakPhonemes.length > 0 
            ? `Weak phonemes detected: ${weakPhonemes.join(", ")}`
            : undefined) ??
          root.summary;

        // Accept multiple possible key names for reference audio coming from backend
        const rawRefCandidates = [
          metricRoot?.reference_audio_url,
          metricRoot?.referenceAudioUrl,
          metricRoot?.reference_audio,
          metricRoot?.reference_url,
          metricRoot?.reference,
          root?.reference_audio_url,
          root?.referenceAudioUrl,
          root?.reference_audio,
          root?.reference_url,
          root?.reference,
        ];

        let referenceAudioUrl: string | undefined = undefined;
        for (const cand of rawRefCandidates) {
          if (typeof cand === "string" && cand.trim() !== "") {
            referenceAudioUrl = cand.trim();
            break;
          }
        }

        // If we have a relative path, build a full URL using the apiClient baseURL
        if (referenceAudioUrl) {
          const isAbsolute = /^https?:\/\//i.test(referenceAudioUrl);
          if (!isAbsolute) {
            try {
              const apiBase = (apiClient.defaults.baseURL as string) || "";
              // remove trailing /api or /api/ from base to get host root
              const hostRoot = apiBase.replace(/\/?api\/?$/i, "");
              // ensure leading slash on path
              const path = referenceAudioUrl.startsWith("/")
                ? referenceAudioUrl
                : "/" + referenceAudioUrl;
              referenceAudioUrl = hostRoot
                ? hostRoot + path
                : referenceAudioUrl;
            } catch (e) {
              // fallback: leave as-is
            }
          }
        }

        setDetailedResults({
          overallScore,
          mistakesSummary,
          phonemes,
          words,
          referenceAudioUrl,
          weakPhonemes,
        });
      } else {
        const body = await response.text().catch(() => "<unreadable response>");
        console.error(
          "Upload failed:",
          response.status,
          response.statusText,
          body
        );
        setUploadMessage("Upload failed. Please try again.");
      }
    } catch (err) {
      console.error(err);
      setUploadMessage("Upload error. Check network or backend.");
    } finally {
      setIsUploading(false);
    }
  };

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
      if (
        mediaRecorderRef.current &&
        mediaRecorderRef.current.state !== "inactive"
      ) {
        try {
          mediaRecorderRef.current.stop();
        } catch {}
      }
      if (metricsAnimationFrameRef.current !== null) {
        cancelAnimationFrame(metricsAnimationFrameRef.current);
      }
    };
  }, []);

  // Smoothly animate metrics numbers when new scores arrive
  useEffect(() => {
    if (!lastMetrics) return;

    const hasNumericMetrics =
      typeof lastMetrics.fluency_score === "number" ||
      typeof lastMetrics.phoneme_accuracy === "number" ||
      typeof lastMetrics.word_accuracy === "number";

    if (!hasNumericMetrics) {
      setAnimatedMetrics(lastMetrics);
      return;
    }

    const startTimestamp = performance.now();
    const duration = 800; // ms

    const startValues = {
      fluency_score: 0,
      phoneme_accuracy: 0,
      word_accuracy: 0,
    };

    const targetValues = {
      fluency_score: lastMetrics.fluency_score ?? 0,
      phoneme_accuracy: lastMetrics.phoneme_accuracy ?? 0,
      word_accuracy: lastMetrics.word_accuracy ?? 0,
    };

    const animate = (now: number) => {
      const elapsed = now - startTimestamp;
      const progress = Math.min(1, elapsed / duration);
      const easeOut = 1 - Math.pow(1 - progress, 3);

      setAnimatedMetrics({
        fluency_score:
          lastMetrics.fluency_score !== undefined
            ? startValues.fluency_score +
              (targetValues.fluency_score - startValues.fluency_score) * easeOut
            : undefined,
        phoneme_accuracy:
          lastMetrics.phoneme_accuracy !== undefined
            ? startValues.phoneme_accuracy +
              (targetValues.phoneme_accuracy - startValues.phoneme_accuracy) *
                easeOut
            : undefined,
        word_accuracy:
          lastMetrics.word_accuracy !== undefined
            ? startValues.word_accuracy +
              (targetValues.word_accuracy - startValues.word_accuracy) * easeOut
            : undefined,
      });

      if (progress < 1) {
        metricsAnimationFrameRef.current = requestAnimationFrame(animate);
      }
    };

    if (metricsAnimationFrameRef.current !== null) {
      cancelAnimationFrame(metricsAnimationFrameRef.current);
    }
    metricsAnimationFrameRef.current = requestAnimationFrame(animate);
  }, [lastMetrics]);

  // format timer mm:ss
  const formatTime = (seconds: number) => {
    const mm = Math.floor(seconds / 60)
      .toString()
      .padStart(2, "0");
    const ss = (seconds % 60).toString().padStart(2, "0");
    return `${mm}:${ss}`;
  };

  const getScorePhrase = (score?: number) => {
    if (score === undefined || Number.isNaN(score)) return "";
    const clamped = Math.min(100, Math.max(0, Math.round(score)));
    return SCORE_PHRASES[clamped] ?? "";
  };

  // Text-to-speech function to read the sentence aloud
  const speakSentence = (text: string) => {
    try {
      const synth = window.speechSynthesis;
      if (!synth) {
        alert("Text-to-speech is not supported in your browser.");
        return;
      }

      // Cancel any ongoing speech
      synth.cancel();

      const utterance = new SpeechSynthesisUtterance(text);
      const voices = synth.getVoices() || [];

      // Find a female voice (prefer US or UK English)
      const findFemaleVoice = (v: SpeechSynthesisVoice) => {
        const name = (v.name || "").toLowerCase();
        return /female|woman|zira|amy|susan|kathy|google us english female|google uk english female/.test(
          name
        );
      };

      utterance.voice =
        voices.find(findFemaleVoice) ||
        voices.find((v) => /^en/i.test(v.lang)) ||
        voices[0];
      utterance.rate = 0.5; // Slightly slower for clarity
      utterance.pitch = 1.0;

      utterance.onstart = () => setIsSpeaking(true);
      utterance.onend = () => setIsSpeaking(false);
      utterance.onerror = () => setIsSpeaking(false);

      synth.speak(utterance);
    } catch (error) {
      console.error("Text-to-speech error:", error);
      alert("Failed to play text-to-speech. Please try again.");
      setIsSpeaking(false);
    }
  };

  // Stop speaking function
  const stopSpeaking = () => {
    try {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } catch (error) {
      console.error("Error stopping speech:", error);
    }
  };

  return (
    <div className="assessment-container">
      <header className="assessment-header">
        <div className="assessment-header-inner">
          <div className="assessment-title-block">
            <div className="assessment-wave-icon" aria-hidden="true">
              <span />
              <span />
              <span />
            </div>
            <div>
              <h1 className="assessment-title">Speech Assessment</h1>
              <p className="assessment-subtitle"></p>
            </div>
          </div>
          <button
            className="back-button"
            onClick={() => navigate("/dashboard")}
          >
            ← Back to Dashboard
          </button>
        </div>
      </header>

      <main className="assessment-content">
        <div className="assessment-wrapper">
          {/* Progress bar */}
          <div className="assessment-progress">
            <div className="progress-bar">
              <div className="progress-fill" style={{ width: "100%" }} />
            </div>
            <p className="progress-text">
              Sentence {currentSentenceIndex + 1} of{" "}
              {assessmentSentences.length}
            </p>
          </div>

          {/* Sentence card */}
          <div className={`sentence-card ${!recommendedFetched ? 'recommendation-placeholder' : ''}`}>
            <div className={`sentence-display ${!recommendedFetched ? 'recommendation-content' : ''}`}>
              {!recommendedFetched ? (
                // Before recommendation: Show stylish placeholder - centered
                <div style={{ 
                  textAlign: "center", 
                  padding: "40px 20px",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "100%"
                }}>
                  <div
                    style={{
                      fontSize: "3rem",
                      marginBottom: "20px",
                      opacity: 0.3,
                    }}
                  >
                    📝
                  </div>
                  <h3
                    style={{
                      fontSize: "1.3rem",
                      fontWeight: 600,
                      color: "#6366f1",
                      marginBottom: "12px",
                      textAlign: "center",
                    }}
                  >
                    Get Your Personalized Sentence
                  </h3>
                  <p
                    style={{
                      color: "#6b7280",
                      fontSize: "0.95rem",
                      marginBottom: "32px",
                      maxWidth: "500px",
                      marginLeft: "auto",
                      marginRight: "auto",
                      textAlign: "center",
                      lineHeight: 1.6,
                    }}
                  >
                    Click the button below to receive a sentence tailored to
                    your speech improvement needs
                  </p>
                  <button
                    className="recommend-btn"
                    onClick={fetchRecommendedSentence}
                    disabled={recommendLoading}
                    style={{
                      padding: "14px 36px",
                      fontSize: "1rem",
                      fontWeight: 600,
                      borderRadius: "12px",
                    }}
                  >
                    {recommendLoading ? (
                      <>
                        <span
                          className="spinner"
                          style={{ marginRight: 8 }}
                          aria-hidden
                        />
                        Loading...
                      </>
                    ) : (
                      <>
                        <span style={{ marginRight: 8 }}>✨</span>
                        Recommend Sentence
                      </>
                    )}
                  </button>
                </div>
              ) : (
                // After recommendation: Show sentence with badge
                <>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      marginBottom: "16px",
                    }}
                  >
                    <span
                      className="recommended-badge"
                      style={{
                        background: "linear-gradient(135deg, #6366f1, #8b5cf6)",
                        color: "white",
                        padding: "6px 16px",
                        borderRadius: "20px",
                        fontSize: "0.85rem",
                        fontWeight: 600,
                        boxShadow: "0 2px 8px rgba(99, 102, 241, 0.3)",
                      }}
                    >
                      ✨ Recommended for You
                    </span>
                  </div>
                  <h2
                    className="sentence-text"
                    style={{
                      fontSize: "1.5rem",
                      lineHeight: "1.6",
                      color: "#1f2937",
                      marginBottom: "16px",
                      padding: "20px",
                      background: "linear-gradient(135deg, #f0f9ff, #e0f2fe)",
                      borderLeft: "4px solid #6366f1",
                      borderRadius: "8px",
                    }}
                  >
                    {sentenceText}
                  </h2>
                  <p
                    className="sentence-instruction"
                    style={{
                      color: "#6b7280",
                      fontSize: "0.9rem",
                      fontStyle: "italic",
                      textAlign: "center",
                    }}
                  >
                    📢 Read the sentence aloud clearly and naturally
                  </p>
                </>
              )}
            </div>
          </div>

          {/* Recording card */}
          <div
            className={`recording-card ${
              isRecording ? "recording-active" : ""
            }`}
          >
            {isUploading && (
              <div className="upload-overlay" aria-label="Uploading audio">
                <span className="spinner dark" aria-hidden />
                <span className="overlay-text">Uploading audio…</span>
              </div>
            )}
            <h3 className="recording-title">Record Your Speech</h3>

            {/* Recording controls: compact start button + waveform + timer */}
            {!recordedAudio ? (
              <div className="recording-controls">
                {!isRecording ? (
                  <button
                    className="record-button pulse"
                    onClick={startRecording}
                    aria-label="Start Recording"
                    disabled={!recommendedFetched}
                  >
                    <span className="record-icon">
                      <MicIcon />
                    </span>
                    Start Recording
                  </button>
                ) : (
                  <button
                    className="record-button recording"
                    onClick={stopRecording}
                    aria-label="Stop Recording"
                  >
                    <span className="dot-indicator" /> Stop Recording
                  </button>
                )}

                {/* waveform-like animation while recording */}
                {isRecording && (
                  <div className="recording-visualizer" aria-hidden>
                    <span className="bar b1" />
                    <span className="bar b2" />
                    <span className="bar b3" />
                    <span className="bar b4" />
                    <span className="bar b5" />
                  </div>
                )}

                {/* timer */}
                {isRecording && (
                  <div className="timer-box">
                    <span className="record-timer">
                      {formatTime(recordTime)}
                    </span>
                  </div>
                )}

                {/* hint */}
                <p className="recording-hint">
                  {isRecording
                    ? "Recording... click Stop when finished."
                    : !recommendedFetched
                    ? "Please click 'Recommend sentence' first."
                    : "Click Start to begin recording."}
                </p>

                {/* DEV bypass removed in production; analysis uses backend only. */}

                {/* decorative ambient sound waves in free space */}
                <div className="ambient-waves" aria-hidden="true">
                  <div className="ambient-wave ambient-wave-1" />
                  <div className="ambient-wave ambient-wave-2" />
                  <div className="ambient-wave ambient-wave-3" />
                </div>
              </div>
            ) : (
              /* Playback + actions */
              <div className="playback-controls">
                <div className="audio-player">
                  <span className="replay-caption">Your recording</span>
                  <audio
                    ref={audioElementRef}
                    src={audioURL}
                    controls
                    className="audio-element"
                    onPlay={() => setIsPlaybackPlaying(true)}
                    onPause={() => setIsPlaybackPlaying(false)}
                    onEnded={() => setIsPlaybackPlaying(false)}
                  />
                  {isPlaybackPlaying && (
                    <div className="playback-visualizer" aria-hidden>
                      <span className="p-bar pb1" />
                      <span className="p-bar pb2" />
                      <span className="p-bar pb3" />
                      <span className="p-bar pb4" />
                      <span className="p-bar pb5" />
                    </div>
                  )}
                </div>

                <div className="action-buttons">
                  <button
                    className="action-btn rerecord-btn"
                    onClick={reRecord}
                    disabled={isUploading}
                  >
                    Re-record
                  </button>

                  <button
                    className="action-btn upload-btn"
                    onClick={uploadAudio}
                    disabled={isUploading}
                  >
                    {isUploading ? (
                      <>
                        <span className="spinner" aria-hidden />
                        Analyzing...
                      </>
                    ) : (
                      "Analyze"
                    )}
                  </button>
                </div>

                {uploadMessage && (
                  <p
                    className={`upload-message ${
                      uploadMessage.startsWith("✓") ? "success" : "error"
                    }`}
                  >
                    {uploadMessage}
                  </p>
                )}

                
                {detailedResults && (
                  <div style={{ marginTop: 24, padding: 24, backgroundColor: "#f0f9ff", borderRadius: 16, border: "3px solid #3b82f6", boxShadow: "0 8px 24px rgba(59, 130, 246, 0.15)" }}>
                    <h3 style={{ marginTop: 0, marginBottom: 20, color: "#1e40af", display: "flex", alignItems: "center", gap: 10, fontSize: '1.75rem', fontWeight: 700 }}>
                      <span style={{ fontSize: 32 }}>📊</span>
                      Assessment Results
                    </h3>

                    {/* Speedometer Gauge for Word Accuracy */}
                    {lastMetrics?.word_accuracy !== undefined && (
                      <div style={{ marginBottom: 24, padding: 24, backgroundColor: "white", borderRadius: 16, textAlign: "center", boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)" }}>
                        <SpeedometerGauge score={lastMetrics.word_accuracy} />
                        <div style={{ fontSize: 16, color: "#6b7280", fontWeight: 600, marginTop: 8 }}>
                          {lastMetrics.word_accuracy >= 80 ? "🎉 Excellent pronunciation!" : lastMetrics.word_accuracy >= 60 ? "👍 Good job!" : "💪 Keep practicing!"}
                        </div>
                      </div>
                    )}

                    {/* Overall Score */}
                    {typeof detailedResults.overallScore === "number" && (
                      <div style={{ marginBottom: 20, padding: 24, backgroundColor: "white", borderRadius: 16, textAlign: "center", boxShadow: "0 4px 12px rgba(0, 0, 0, 0.08)" }}>
                        <div style={{ fontSize: 16, color: "#6b7280", marginBottom: 8, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>Overall Sentence Score</div>
                        <div style={{ fontSize: 64, fontWeight: 800, color: "#3b82f6", marginBottom: 8 }}>
                          {Math.round(detailedResults.overallScore)}
                        </div>
                        {getScorePhrase(detailedResults.overallScore) && (
                          <div style={{ fontSize: 16, color: "#6b7280", fontWeight: 600 }}>
                            {getScorePhrase(detailedResults.overallScore)}
                          </div>
                        )}
                      </div>
                    )}

                    {/* Metric Cards - Display all accuracy metrics */}
                    {lastMetrics && (
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16, marginBottom: 20 }}>
                        <div style={{ padding: 16, backgroundColor: "white", borderRadius: 12, textAlign: "center", border: "2px solid #e0e7ff", boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                          <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 6, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>Phoneme Accuracy</div>
                          <div style={{ fontSize: 32, fontWeight: 700, color: "#6366f1" }}>
                            {lastMetrics.phoneme_accuracy === undefined
                              ? "N/A"
                              : Math.round(
                                  animatedMetrics.phoneme_accuracy ??
                                    lastMetrics.phoneme_accuracy
                                )}
                          </div>
                        </div>
                        <div style={{ padding: 16, backgroundColor: "white", borderRadius: 12, textAlign: "center", border: "2px solid #e0e7ff", boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                          <div style={{ fontSize: 13, color: "#6b7280", marginBottom: 6, fontWeight: 600, textTransform: "uppercase", letterSpacing: "0.5px" }}>Fluency Score</div>
                          <div style={{ fontSize: 32, fontWeight: 700, color: "#6366f1" }}>
                            {lastMetrics.fluency_score === undefined
                              ? "N/A"
                              : Math.round(
                                  animatedMetrics.fluency_score ??
                                    lastMetrics.fluency_score
                                )}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Detailed Phoneme Results */}
                    {detailedResults.phonemes && detailedResults.phonemes.length > 0 && (
                      <div style={{ marginTop: 20, padding: 20, backgroundColor: "white", borderRadius: 12, boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                        <h4 style={{ marginTop: 0, marginBottom: 16, fontSize: 18, fontWeight: 700, color: "#374151" }}>Phoneme Breakdown</h4>
                        <div className="phoneme-grid">
                          {detailedResults.phonemes.map((p, idx) => {
                            const acc = p.accuracy;
                            const band = acc >= 80 ? "good" : acc >= 50 ? "ok" : "bad";
                            return (
                              <div
                                key={`${p.symbol}-${idx}`}
                                className={`phoneme-chip ${band}`}
                              >
                                <span className="phoneme-symbol">{p.symbol}</span>
                                <span className="phoneme-score">{Math.round(acc)}</span>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                    )}

                    {/* Word-by-Word Analysis */}
                    {detailedResults.words && detailedResults.words.length > 0 && (
                      <div style={{ marginTop: 20, padding: 20, backgroundColor: "white", borderRadius: 12, boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                        <h4 style={{ marginTop: 0, marginBottom: 16, fontSize: 18, fontWeight: 700, color: "#374151" }}>Word-by-Word Analysis</h4>
                        <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                          {detailedResults.words.map((w, idx) => (
                            <span
                              key={idx}
                              style={{
                                padding: "8px 16px",
                                borderRadius: 8,
                                fontSize: 14,
                                fontWeight: 600,
                                backgroundColor: w.correct ? "#d1fae5" : "#fee2e2",
                                color: w.correct ? "#065f46" : "#991b1b",
                                border: `2px solid ${w.correct ? "#6ee7b7" : "#fca5a5"}`,
                              }}
                            >
                              {w.correct ? "✓" : "✗"} {w.text}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Weak Phonemes */}
                    {detailedResults.weakPhonemes && detailedResults.weakPhonemes.length > 0 && (
                      <div style={{ marginTop: 20, padding: 20, backgroundColor: "white", borderRadius: 12, boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                        <h4 style={{ marginTop: 0, marginBottom: 12, fontSize: 18, fontWeight: 700, color: "#374151" }}>Weak Phonemes Detected</h4>
                        <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                          {detailedResults.weakPhonemes.map((phoneme, idx) => (
                            <span
                              key={idx}
                              style={{
                                padding: "8px 16px",
                                backgroundColor: "#fef3c7",
                                color: "#92400e",
                                borderRadius: 20,
                                fontSize: 14,
                                fontWeight: 700,
                                border: "2px solid #fbbf24"
                              }}
                            >
                              {phoneme}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Replay Options */}
                    <div style={{ marginTop: 20, padding: 20, backgroundColor: "white", borderRadius: 12, boxShadow: "0 2px 8px rgba(0, 0, 0, 0.05)" }}>
                      <h4 style={{ marginTop: 0, marginBottom: 16, fontSize: 18, fontWeight: 700, color: "#374151" }}>Audio Playback</h4>
                      <div className="replay-players">
                        <div className="replay-block">
                          <span className="replay-caption subtle">Your recording</span>
                          <audio
                            src={audioURL}
                            controls
                            className="audio-element small"
                            onPlay={() => setIsPlaybackPlaying(true)}
                            onPause={() => setIsPlaybackPlaying(false)}
                            onEnded={() => setIsPlaybackPlaying(false)}
                          />
                          {isPlaybackPlaying && (
                            <div className="playback-visualizer" aria-hidden>
                              <span className="p-bar pb1" />
                              <span className="p-bar pb2" />
                              <span className="p-bar pb3" />
                              <span className="p-bar pb4" />
                              <span className="p-bar pb5" />
                            </div>
                          )}
                        </div>
                        <div className="replay-block">
                          <span className="replay-caption subtle">Reference audio</span>
                          {detailedResults.referenceAudioUrl ? (
                            <div className="reference-with-audio" aria-live="polite">
                              <div className="ref-badge ref-available">Reference available</div>
                              <div className="ref-audio-row">
                                <audio
                                  src={detailedResults.referenceAudioUrl}
                                  controls
                                  className="audio-element small"
                                  onPlay={() => setIsPlaybackPlaying(true)}
                                  onPause={() => setIsPlaybackPlaying(false)}
                                  onEnded={() => setIsPlaybackPlaying(false)}
                                />
                                <div className="ref-wave" aria-hidden>
                                  <span className="rw-bar rw1" />
                                  <span className="rw-bar rw2" />
                                  <span className="rw-bar rw3" />
                                  <span className="rw-bar rw4" />
                                  <span className="rw-bar rw5" />
                                </div>
                              </div>
                            </div>
                          ) : (
                            <div className="reference-placeholder" aria-live="polite">
                              <div className="ref-cartoon" aria-hidden>
                                <img
                                  src={roboGif}
                                  alt="Robot placeholder"
                                  className="robot-asset"
                                />
                              </div>
                              <div>
                                <div className="ref-text">Reference audio of current sentence</div>
                                <button
                                  className="action-btn"
                                  onClick={() =>
                                    isSpeaking
                                      ? stopSpeaking()
                                      : speakSentence(sentenceText)
                                  }
                                  style={{
                                    marginTop: 12,
                                    fontSize: 14,
                                    padding: "8px 16px",
                                  }}
                                >
                                  {isSpeaking ? (
                                    <>
                                      <span
                                        className="spinner"
                                        aria-hidden
                                        style={{ marginRight: 6 }}
                                      />
                                      Stop Speaking
                                    </>
                                  ) : (
                                    <>🔊 Listen to Sentence</>
                                  )}
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
          <div className="results-actions" style={{textAlign: 'center', marginTop: 14}}>
            <button
              className="action-btn recommendations-btn"
              onClick={() => {
                if (!detailedResults) {
                  setAlertModal({
                    visible: true,
                    title: "Assessment Required",
                    message: "Please attempt a single assessment before viewing recommendations."
                  });
                  return;
                }
                const payload = {
                  detailedResults: detailedResults,
                  lastMetrics: lastMetrics,
                  audioURL: audioURL,
                  sentence: sentenceText,
                };
                try {
                  sessionStorage.setItem("last_assessment", JSON.stringify(payload));
                } catch (e) {}
                navigate("/recommendations", { state: payload });
              }}
            >
              View Recommendations
            </button>
          </div>
        </div>
      </main>
      <InfoModal
        visible={alertModal.visible}
        title={alertModal.title}
        message={alertModal.message}
        onClose={() => setAlertModal({ visible: false, message: "" })}
      />
    </div>
  );
};

export default AssessmentPage;
