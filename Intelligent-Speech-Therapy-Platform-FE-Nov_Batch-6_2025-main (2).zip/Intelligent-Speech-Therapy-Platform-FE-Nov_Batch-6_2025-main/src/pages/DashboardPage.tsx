// DashboardPage.tsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { fetchPrevResults, fetchAssessmentHistory, type AssessmentHistoryItem } from "../api/historyApi";
import ScoreChart from "../components/dashboard/ScoreChart";
import AssessmentHistory from "../components/dashboard/AssessmentHistory";
import "./DashboardPage.css";

import illu5 from "../assets/illu5.jpg";
import illu6 from "../assets/illu6.jpg";
import illu7 from "../assets/illu7.jpg";
import illu8 from "../assets/illu8.jpg";
import illu9 from "../assets/illu9.jpg";
import illu4 from "../assets/illu4.jpg";

const images = [illu5, illu6, illu7, illu8, illu9, illu4];

const DashboardPage = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [current, setCurrent] = useState(0);
  const [isNavigating, setIsNavigating] = useState(false);
  const [assessmentHistory, setAssessmentHistory] = useState<AssessmentHistoryItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeSection, setActiveSection] =
    useState<"assessment" | "scores" | "history">("assessment");

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrent((c) => (c + 1) % images.length);
    }, 1600);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const loadHistory = async () => {
      setLoading(true);
      try {
        const userId = user?.id ?? localStorage.getItem("user_id") ?? "1";
        const history = await fetchPrevResults(userId);
        setAssessmentHistory(history.length ? history : await fetchAssessmentHistory());
      } catch {
        setAssessmentHistory(await fetchAssessmentHistory());
      } finally {
        setLoading(false);
      }
    };
    loadHistory();
  }, [user]);

  const latest = assessmentHistory[assessmentHistory.length - 1];

  return (
    <div className="dashboard-container">
      {/* HEADER */}
      <header className="dashboard-header">
        <div className="dashboard-logo">Speech Therapy Platform</div>
        <div className="account-menu">
          <button className="account-button" onClick={() => setDropdownOpen(!dropdownOpen)}>
            <span>Account</span>
            <div className="user-icon">{user?.fullName?.[0] ?? "U"}</div>
          </button>
          {dropdownOpen && (
            <div className="dropdown-menu">
              <div className="dropdown-user-info">
                <div className="dropdown-user-name">{user?.fullName}</div>
                <div className="dropdown-user-email">{user?.email}</div>
              </div>
              <hr />
              <button
                className="dropdown-item logout-btn"
                onClick={() => {
                  logout();
                  navigate("/login");
                }}
              >
                Logout
              </button>
            </div>
          )}
        </div>
      </header>

      <div className="dashboard-main">
        {/* SIDEBAR */}
        <aside className="dashboard-sidebar">
          <h3 className="nav-title">Menu</h3>
          <button className={`nav-item ${activeSection === "assessment" && "active"}`} onClick={() => setActiveSection("assessment")}>Assessment</button>
          <button className={`nav-item ${activeSection === "scores" && "active"}`} onClick={() => setActiveSection("scores")}>Score Trends</button>
          <button className={`nav-item ${activeSection === "history" && "active"}`} onClick={() => setActiveSection("history")}>Assessment History</button>
        </aside>

        {/* CONTENT */}
        <main className="dashboard-content">
          <h1 className="welcome-title">Welcome {user?.fullName}!</h1>
          <p className="welcome-subtitle">
            Continue your personalized speech therapy program and monitor your improvement.
          </p>

          {/* LATEST ASSESSMENT */}
          {latest && (
            <div className="latest-card">
              <h3>Latest Assessment</h3>
              <div className="latest-metrics">
                <div className="progress-ring" style={{ "--percent": `${latest.word_accuracy}%` } as React.CSSProperties}>
                  <span>{latest.word_accuracy}%</span>
                </div>
                <div className="progress-ring" style={{ "--percent": `${latest.sent_accuracy ?? latest.word_accuracy}%` } as React.CSSProperties}>
                  <span>{latest.sent_accuracy ?? latest.word_accuracy}%</span>
                </div>
              </div>
            </div>
          )}

          {/* SECTIONS */}
          {!loading && activeSection === "assessment" && (
            <div className="carousel-wrapper">
              {images.slice(current, current + 3).map((img, i) => (
                <div key={i} className={`carousel-card ${i === 1 ? "active" : ""}`}>
                  <img src={img} />
                </div>
              ))}
              <button className="start-journey-button" onClick={() => navigate("/assessment")}>
                Start Your Journey
              </button>
            </div>
          )}

          {!loading && activeSection === "scores" && (
            <div className="dashboard-section">
              <ScoreChart data={assessmentHistory.map(a => ({
                date: a.date,
                word: a.word_accuracy,
                sentence: a.sent_accuracy ?? a.word_accuracy
              }))} />
            </div>
          )}

          {!loading && activeSection === "history" && (
            <div className="dashboard-section">
              <AssessmentHistory assessments={assessmentHistory} />
            </div>
          )}
        </main>
      </div>
    </div>
  );
};

export default DashboardPage;
