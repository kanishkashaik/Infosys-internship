import React, { useMemo } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { AssessmentHistoryItem } from "../../api/historyApi";
import "./PhonemePatterns.css";

interface PhonemePatternsProps {
  assessments: AssessmentHistoryItem[];
}

interface PhonemeFrequency {
  phoneme: string;
  count: number;
  frequency: number; // percentage
}

const PhonemePatterns: React.FC<PhonemePatternsProps> = ({ assessments }) => {
  const phonemeData = useMemo(() => {
    const phonemeMap = new Map<string, number>();
    let totalAssessments = 0;

    assessments.forEach((assessment) => {
      const phonemes = assessment.weak_phonemes || assessment.weak_Phoneme || [];
      if (phonemes.length > 0) {
        totalAssessments++;
        phonemes.forEach((phoneme) => {
          phonemeMap.set(phoneme, (phonemeMap.get(phoneme) || 0) + 1);
        });
      }
    });

    const data: PhonemeFrequency[] = Array.from(phonemeMap.entries())
      .map(([phoneme, count]) => ({
        phoneme,
        count,
        frequency: totalAssessments > 0 ? (count / totalAssessments) * 100 : 0,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10); // Top 10 most frequent

    return data;
  }, [assessments]);

  if (phonemeData.length === 0) {
    return (
      <div className="phoneme-patterns-empty">
        <p>No weak phoneme patterns detected yet. Complete more assessments to see patterns!</p>
      </div>
    );
  }

  return (
    <div className="phoneme-patterns-container">
      <h3 className="phoneme-patterns-title">Weak Phoneme Patterns Over Time</h3>
      <p className="phoneme-patterns-subtitle">
        Most frequently identified weak phonemes across all assessments
      </p>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={phonemeData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis 
            dataKey="phoneme" 
            stroke="#6b7280"
            style={{ fontSize: "12px" }}
          />
          <YAxis 
            stroke="#6b7280"
            style={{ fontSize: "12px" }}
            label={{ value: "Occurrences", angle: -90, position: "insideLeft" }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: "#fff", 
              border: "1px solid rgba(245, 158, 11, 0.25)",
              borderRadius: "12px",
              boxShadow: "0 8px 24px rgba(245, 158, 11, 0.2)",
              padding: "12px 16px"
            }}
            formatter={(value: number | undefined, name: string | undefined) => {
              if (name === "count" && value !== undefined) {
                return [`${value} time${value !== 1 ? "s" : ""}`, "Occurrences"];
              }
              return [value ?? 0];
            }}
            labelStyle={{ fontWeight: 600, color: "#f59e0b", marginBottom: "8px" }}
          />
          <defs>
            <linearGradient id="barGradient" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity={1} />
              <stop offset="50%" stopColor="#fbbf24" stopOpacity={0.95} />
              <stop offset="100%" stopColor="#fcd34d" stopOpacity={0.85} />
            </linearGradient>
          </defs>
          <Bar 
            dataKey="count" 
            fill="url(#barGradient)"
            radius={[8, 8, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
      <div className="phoneme-patterns-list">
        {phonemeData.map((item) => (
          <div key={item.phoneme} className="phoneme-pattern-item">
            <span className="phoneme-pattern-phoneme">{item.phoneme}</span>
            <span className="phoneme-pattern-stats">
              {item.count} occurrence{item.count !== 1 ? "s" : ""} ({item.frequency.toFixed(1)}%)
            </span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PhonemePatterns;

