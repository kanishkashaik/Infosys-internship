import React from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import "./ScoreChart.css";

interface ScoreData {
  date: string;
  word: number;
  sentence: number;
  fluency?: number;
  phoneme?: number;
}

interface ScoreChartProps {
  data: ScoreData[];
}

const ScoreChart: React.FC<ScoreChartProps> = ({ data }) => {
  if (data.length === 0) {
    return (
      <div className="score-chart-empty">
        <p>No assessment data available yet. Complete assessments to see your progress!</p>
      </div>
    );
  }

  // Calculate statistics
  const avgWord = data.reduce((sum, d) => sum + d.word, 0) / data.length;
  const avgSentence = data.reduce((sum, d) => sum + d.sentence, 0) / data.length;
  const avgFluency = data.reduce((sum, d) => sum + (d.fluency || 0), 0) / data.length;
  const avgPhoneme = data.reduce((sum, d) => sum + (d.phoneme || 0), 0) / data.length;
  const latestWord = data[data.length - 1]?.word || 0;
  const latestSentence = data[data.length - 1]?.sentence || 0;
  const latestFluency = data[data.length - 1]?.fluency || 0;
  const latestPhoneme = data[data.length - 1]?.phoneme || 0;

  return (
    <div className="score-chart-container">
      <div className="score-chart-header">
        <h3 className="score-chart-title">Score Trends Over Time</h3>
        <div className="score-chart-stats">
          <div className="stat-mini">
            <span className="stat-mini-label">Avg Word Accuracy</span>
            <span className="stat-mini-value">{avgWord.toFixed(1)}%</span>
          </div>
          <div className="stat-mini">
            <span className="stat-mini-label">Avg Sentence Accuracy</span>
            <span className="stat-mini-value">{avgSentence.toFixed(1)}%</span>
          </div>
          {avgFluency > 0 && (
            <div className="stat-mini">
              <span className="stat-mini-label">Avg Fluency</span>
              <span className="stat-mini-value">{avgFluency.toFixed(1)}%</span>
            </div>
          )}
        </div>
      </div>
      <div className="score-chart-insights">
        <div className="insight-card">
          <span className="insight-icon">📊</span>
          <div>
            <span className="insight-label">Latest Assessment</span>
            <span className="insight-value">Word: {latestWord.toFixed(1)}% | Sentence: {latestSentence.toFixed(1)}%</span>
          </div>
        </div>
        <div className="insight-card">
          <span className="insight-icon">📈</span>
          <div>
            <span className="insight-label">Total Assessments</span>
            <span className="insight-value">{data.length}</span>
          </div>
        </div>
      </div>
      <ResponsiveContainer width="100%" height={320}>
        <LineChart data={data} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis 
            dataKey="date" 
            stroke="#6b7280"
            style={{ fontSize: "12px" }}
            tickFormatter={(value) => {
              const date = new Date(value);
              return `${date.getMonth() + 1}/${date.getDate()}`;
            }}
          />
          <YAxis 
            domain={[0, 100]}
            stroke="#6b7280"
            style={{ fontSize: "12px" }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: "#fff", 
              border: "1px solid rgba(79, 70, 229, 0.2)",
              borderRadius: "12px",
              boxShadow: "0 8px 24px rgba(79, 70, 229, 0.15)",
              padding: "12px 16px"
            }}
            formatter={(value: number) => [`${value.toFixed(1)}%`, ""]}
            labelFormatter={(label) => `📅 ${new Date(label).toLocaleDateString()}`}
            labelStyle={{ fontWeight: 600, color: "#4f46e5", marginBottom: "8px" }}
          />
          <Legend />
          <Line 
            type="monotone" 
            dataKey="word" 
            stroke="#f59e0b" 
            strokeWidth={3}
            dot={{ fill: "#f59e0b", r: 5, strokeWidth: 2, stroke: "#fff" }}
            activeDot={{ r: 7, stroke: "#f59e0b", strokeWidth: 2 }}
            name="Word Accuracy"
          />
          <Line 
            type="monotone" 
            dataKey="sentence" 
            stroke="#4f46e5" 
            strokeWidth={3}
            dot={{ fill: "#4f46e5", r: 5, strokeWidth: 2, stroke: "#fff" }}
            activeDot={{ r: 7, stroke: "#4f46e5", strokeWidth: 2 }}
            name="Sentence Accuracy"
          />
          {data.some(d => d.fluency && d.fluency > 0) && (
            <Line 
              type="monotone" 
              dataKey="fluency" 
              stroke="#10b981" 
              strokeWidth={3}
              dot={{ fill: "#10b981", r: 5, strokeWidth: 2, stroke: "#fff" }}
              activeDot={{ r: 7, stroke: "#10b981", strokeWidth: 2 }}
              name="Fluency Score"
            />
          )}
          {data.some(d => d.phoneme && d.phoneme > 0) && (
            <Line 
              type="monotone" 
              dataKey="phoneme" 
              stroke="#8b5cf6" 
              strokeWidth={3}
              dot={{ fill: "#8b5cf6", r: 5, strokeWidth: 2, stroke: "#fff" }}
              activeDot={{ r: 7, stroke: "#8b5cf6", strokeWidth: 2 }}
              name="Phoneme Accuracy"
            />
          )}
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};

export default ScoreChart;

