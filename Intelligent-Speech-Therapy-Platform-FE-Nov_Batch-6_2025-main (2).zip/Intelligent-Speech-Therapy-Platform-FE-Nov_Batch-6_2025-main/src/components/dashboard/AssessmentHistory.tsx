import React, { useState } from "react";
import type { AssessmentHistoryItem } from "../../api/historyApi";
import "./AssessmentHistory.css";

interface AssessmentHistoryProps {
  assessments: AssessmentHistoryItem[];
}

const AssessmentHistory: React.FC<AssessmentHistoryProps> = ({ assessments }) => {
  const [selectedAssessment, setSelectedAssessment] = useState<AssessmentHistoryItem | null>(null);

  // Helper function to get badge type based on sentence accuracy
  const getBadgeType = (accuracy: number | undefined): 'bronze' | 'silver' | 'gold' | null => {
    if (accuracy === undefined) return null;
    if (accuracy >= 90) return 'gold';
    if (accuracy >= 75) return 'silver';
    if (accuracy >= 60) return 'bronze';
    return null;
  };

  // Badge component - Award style badge
  const AwardBadge = ({ type }: { type: 'gold' | 'silver' | 'bronze' }) => {
    const colors = {
      gold: { bg: '#d97706', text: '#fff', light: '#f59e0b', dark: '#92400e' },
      silver: { bg: '#6b7280', text: '#fff', light: '#9ca3af', dark: '#4b5563' },
      bronze: { bg: '#92400e', text: '#fff', light: '#b45309', dark: '#78350f' }
    };
    const color = colors[type];
    const label = type.toUpperCase();

    return (
      <svg viewBox="0 0 120 140" fill="none" xmlns="http://www.w3.org/2000/svg" className="award-badge-svg">
        {/* Main circle */}
        <circle cx="60" cy="60" r="52" fill={color.bg} stroke={color.light} strokeWidth="1.5"/>
        {/* Inner highlight circle */}
        <circle cx="60" cy="60" r="48" fill="none" stroke={color.light} strokeWidth="0.8" opacity="0.5"/>
        {/* Laurel wreath decorative lines */}
        <path d="M25 50 Q35 45 45 50 Q55 45 60 48 Q65 45 75 50 Q85 45 95 50" stroke={color.light} strokeWidth="1.2" fill="none" opacity="0.5"/>
        <path d="M25 70 Q35 75 45 70 Q55 75 60 72 Q65 75 75 70 Q85 75 95 70" stroke={color.light} strokeWidth="1.2" fill="none" opacity="0.5"/>
        {/* Crown icon */}
        <path d="M52 32 L55 28 L60 32 L65 28 L68 32 L60 38 Z" fill={color.text} stroke={color.dark} strokeWidth="0.5"/>
        {/* WINNER text */}
        <text x="60" y="52" textAnchor="middle" fill={color.text} fontSize="7" fontWeight="700" fontFamily="Arial, sans-serif" letterSpacing="0.5">WINNER</text>
        {/* GOLD/SILVER/BRONZE text */}
        <text x="60" y="68" textAnchor="middle" fill={color.text} fontSize="12" fontWeight="800" fontFamily="Arial, sans-serif" letterSpacing="1">{label}</text>
        {/* AWARD text */}
        <text x="60" y="78" textAnchor="middle" fill={color.text} fontSize="6" fontWeight="600" fontFamily="Arial, sans-serif" letterSpacing="0.3">AWARD</text>
        {/* Ribbon banner */}
        <path d="M32 98 L60 108 L88 98 L88 128 L60 118 L32 128 Z" fill={color.bg} stroke={color.dark} strokeWidth="0.8"/>
        <path d="M38 102 L60 110 L82 102" stroke={color.light} strokeWidth="1" fill="none" opacity="0.7"/>
        {/* Ribbon serrated bottom */}
        <path d="M32 128 L35 132 L38 128 L41 132 L44 128 L47 132 L50 128 L53 132 L56 128 L59 132 L62 128 L65 132 L68 128 L71 132 L74 128 L77 132 L80 128 L83 132 L86 128 L88 128" stroke={color.dark} strokeWidth="0.5" fill="none"/>
      </svg>
    );
  };

  if (assessments.length === 0) {
    return (
      <div className="assessment-history-empty">
        <p>No assessment history yet. Start your first assessment to see it here!</p>
      </div>
    );
  }

  // Show detailed view if an assessment is selected
  if (selectedAssessment) {
    const phonemes = selectedAssessment.weak_phonemes || selectedAssessment.weak_Phoneme || [];
    const weakWords = selectedAssessment.weak_words || [];
    const sentAccuracy = selectedAssessment.sent_accuracy ?? 0;
    const badgeType = getBadgeType(sentAccuracy);

    return (
      <div className="assessment-history-container">
        <button 
          className="back-button"
          onClick={() => setSelectedAssessment(null)}
        >
          ← Back to List
        </button>
        <div className="assessment-detail-view">
          <h3 className="assessment-history-title">Assessment Details</h3>
          
          <div className="detail-main-section">
            <div className="detail-content-wrapper">
              <div className="detail-sentence-section">
                <h4 className="detail-section-title">Sentence</h4>
                <div className="detail-sentence">
                  {selectedAssessment.sentence_text}
                </div>
              </div>

              <div className="detail-score-section-single">
                <div className="sentence-score-card">
                  <div className="sentence-score-label">Sentence Accuracy</div>
                  <div className="sentence-score-value">{sentAccuracy.toFixed(1)}%</div>
                  <div className="sentence-score-bar-container">
                    <div className="sentence-score-bar">
                      <div 
                        className="sentence-score-bar-fill" 
                        style={{ width: `${sentAccuracy}%` }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="detail-weak-items">
                <div className="detail-weak-section">
                  <h4 className="detail-section-title-small">Weak Words</h4>
                  <div className="detail-words">
                    {weakWords.length > 0 ? (
                      weakWords.map((word, idx) => (
                        <span key={idx} className="word-tag">{word}</span>
                      ))
                    ) : (
                      <span className="no-weak-items">No weak words identified</span>
                    )}
                  </div>
                </div>

                <div className="detail-weak-section">
                  <h4 className="detail-section-title-small">Weak Phonemes</h4>
                  <div className="detail-phonemes">
                    {phonemes.length > 0 ? (
                      phonemes.map((phoneme, idx) => (
                        <span key={idx} className="phoneme-tag-large">{phoneme}</span>
                      ))
                    ) : (
                      <span className="no-weak-items">No weak phonemes identified</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            {badgeType && (
              <div className="detail-badge-container">
                <div className={`award-badge ${badgeType}`}>
                  <AwardBadge type={badgeType} />
                </div>
              </div>
            )}

            <div className="detail-date-bottom">
              {new Date(selectedAssessment.date).toLocaleDateString("en-US", {
                month: "long",
                day: "numeric",
                year: "numeric",
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Show list view
  return (
    <div className="assessment-history-container">
      <h3 className="assessment-history-title">Assessment History</h3>
      
      {/* Assessment List */}
      <div className="assessment-history-list">
        {assessments.map((assessment) => {
          const sentAccuracy = assessment.sent_accuracy ?? 0;
          const badgeType = getBadgeType(sentAccuracy);
          const assessmentDate = new Date(assessment.date);
          
          return (
            <div 
              key={assessment.id} 
              className="assessment-history-item"
              onClick={() => setSelectedAssessment(assessment)}
            >
              {badgeType && (
                <div className={`achievement-badge ${badgeType}`}>
                  <div className={`award-badge ${badgeType}`}>
                    <AwardBadge type={badgeType} />
                  </div>
                </div>
              )}
              <div className="assessment-item-content">
                <p className="assessment-item-sentence">
                  {assessment.sentence_text}
                </p>
                <div className="assessment-item-score-time">
                  <span className="assessment-item-score">{sentAccuracy.toFixed(1)}%</span>
                  <span className="assessment-item-date">
                    {assessmentDate.toLocaleTimeString("en-US", {
                      hour: "2-digit",
                      minute: "2-digit",
                      hour12: true,
                    })}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AssessmentHistory;

