import apiClient from "./apiClient";

export interface AssessmentHistoryItem {
  id: number;
  sentence_id: number;
  sentence_text: string;
  date: string;
  fluency_score: number;
  phoneme_accuracy: number;
  word_accuracy: number;
  weak_Phoneme?: string[];
  // New API fields
  sent_accuracy?: number; // sentence accuracy
  weak_phonemes?: string[]; // lowercase version
  weak_words?: string[];
}

export interface AssessmentHistoryResponse {
  assessments: AssessmentHistoryItem[];
  statusCode?: number;
  message?: string;
}

// New API response structure from /history/prev_results
export interface PrevResultsResponse {
  response: Array<{
    assessemt_date: string; // Note: API has typo "assessemt" instead of "assessment"
    id: number;
    sent_accuracy: number;
    sentence: string;
    sentence_id: number;
    user_id: number;
    weak_phonemes: string[];
    word_accuracy: number;
    weak_words: string[] | null;
  }>;
}

// Fetch assessment history from new endpoint
export const fetchPrevResults = async (userId: string | number): Promise<AssessmentHistoryItem[]> => {
  try {
    const res = await apiClient.get<PrevResultsResponse>(`/history/prev_results?user_id=${userId}`);
    if (res.data?.response && Array.isArray(res.data.response)) {
      const now = new Date();
      // Map the API response to our interface
      // Generate dates going backwards (newer items have more recent dates)
      const mappedData = res.data.response.map((item) => {
        // Use assessemt_date from API, fallback to current date if invalid
        let date: Date;
        try {
          date = new Date(item.assessemt_date);
          if (isNaN(date.getTime())) {
            date = new Date();
          }
        } catch {
          date = new Date();
        }
        return {
          id: item.id,
          sentence_id: item.sentence_id,
          sentence_text: item.sentence,
          date: date.toISOString(),
          fluency_score: 0, // Not provided by API
          phoneme_accuracy: 0, // Not provided by API
          word_accuracy: item.word_accuracy,
          sent_accuracy: item.sent_accuracy,
          weak_phonemes: item.weak_phonemes || [],
          weak_words: item.weak_words || [],
          weak_Phoneme: item.weak_phonemes || [], // Keep for backward compatibility
        };
      });
      
      // Sort by date (most recent first)
      const sortedData = mappedData.sort((a, b) => {
        return new Date(b.date).getTime() - new Date(a.date).getTime();
      });
      
      console.log('📊 Sorted history data:', sortedData.length, 'items');
      return sortedData;
    }
    return [];
  } catch (e) {
    console.error("Failed to fetch prev_results:", e);
    return [];
  }
};

// Fetch assessment history from backend (legacy endpoint)
export const fetchAssessmentHistory = async (): Promise<AssessmentHistoryItem[]> => {
  try {
    const res = await apiClient.get<AssessmentHistoryResponse>("/assessment/history");
    return res.data?.assessments || [];
  } catch (e) {
    // Fallback to localStorage if API fails
    return getLocalAssessmentHistory();
  }
};

// Get assessment history from localStorage (fallback)
export const getLocalAssessmentHistory = (): AssessmentHistoryItem[] => {
  try {
    const stored = localStorage.getItem("assessment_history");
    if (stored) {
      return JSON.parse(stored);
    }
  } catch {}
  return [];
};

// Save assessment to history (called after successful upload)
export const saveAssessmentToHistory = (assessment: AssessmentHistoryItem): void => {
  try {
    const history = getLocalAssessmentHistory();
    history.unshift(assessment); // Add to beginning
    // Keep only last 50 assessments
    const limited = history.slice(0, 50);
    localStorage.setItem("assessment_history", JSON.stringify(limited));
  } catch {}
};

